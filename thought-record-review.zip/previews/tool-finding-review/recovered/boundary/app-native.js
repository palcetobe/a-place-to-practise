'use strict';
(() => {
  const main = document.querySelector('main');
  const dialog = document.querySelector('#reset-dialog');
  const downloadURLs = new Set();
  const empty = () => ({ mode: 'fictional', context: 'friend', choice: '', branch: '', scenario: '', wording: '', anticipated: '', followup: '', personalResponse: '', words: '', difficulty: '', question: '', opportunity: '', selected: [], showFeedback: false, showResponse: false, writingOpen: false });
  let state = empty();
  let current = 'intro';
  let resetDestination = 'complete';
  let hostExitAfterFinish=null;
  let returnFocus = null;
  const routes = new Set(['intro','learn','example','practise','choose','rehearse','response','everyday','reflection','summary','complete','sources','clinician']);
  const safe = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const btn = (text, action, primary = false) => `<button data-action="${action}"${primary ? ' class="primary"' : ''}>${text}</button>`;
  const goButton = (text, route, primary = false) => btn(text, `go:${route}`, primary);
  const actions = (...content) => `<div class="actions">${content.join('')}</div>`;
  const line = (speaker, words) => `<p class="line ${speaker !== 'Alex' ? 'sam' : ''}"><span class="speaker">${speaker}</span>${words}</p>`;
  const examples = {
    friend: {
      label: 'A friend asks for a lift', person: 'Sam',
      scenario: `<p>Alex and Sam are friends, finishing an afternoon walk. Sam asks for a lift to the mall tonight for a non-urgent errand.</p><p>Alex needs to stay in tonight to study, even if the trip would be short. Alex hasn't promised a lift. Sam isn't stranded and there's no emergency.</p>`,
      request: 'Can you give me a lift to the mall tonight?',
      model: "No, I need to stay in tonight to study.",
      pushback: 'Just a lift there? I can get myself back.',
      repeat: "No, I'm not available to take you tonight.",
      ending: "Okay, I'll figure something out.",
      note: "Alex states a limit and repeats it without blaming Sam or promising another day. Sam's errand remains unresolved.",
      rehearsal: 'Alex needs to stay in to study. Sam asks for a nonurgent lift to the mall, with no prior promise.',
      alternative: "I'm not available to drive tonight",
      choices: [['maybe', "Maybe. Text me later and we'll see."], ['clear', "No, I need to stay in tonight to study."], ['blame', "I'm not your taxi. You always expect me to drive you."]],
      feedback: {
        maybe: "This leaves the request open. If Alex means no tonight, naming that limit would be clearer. 'Maybe' fits if Alex is truly unsure.",
        clear: "This states tonight's limit without blaming Sam. Sam may still be disappointed or ask again. Different words can communicate the same choice.",
        blame: "This pushes back but adds an accusation. 'Always' isn't a fact in this example. Alex can remove the accusation and say what they are available for."
      },
      branchLabels: [['acceptance', 'Accepts the limit'], ['disappointment', 'Feels disappointed'], ['shorter', 'Asks for a shorter trip']],
      replies: {
        acceptance: ['Okay, thanks for letting me know.', '', 'Alex can end the exchange there. Sam still arranges their own errand. No extra offer is needed.'],
        disappointment: ['Oh. I was hoping you could.', "No, I'm not available to take you tonight.", 'Alex keeps the same limit without blaming Sam. Sam might still disagree.'],
        shorter: ["Just a lift there? I can get myself back.", "No, I'm not available to take you tonight.", 'A shorter trip still conflicts with staying in to study. Repeating the limit is one option, not a way to guarantee the pressure stops.']
      }
    },
    family: {
      label: 'A family member invites you to dinner', person: 'Jo',
      scenario: `<p>During a casual visit, Jo invites her adult child Alex to dinner next Sunday.</p><p>Alex has been looking forward to a Sunday day trip with a friend. They plan to hike outside the city and expect to return late. Alex enjoys family get-togethers and wants to keep these plans. Alex hasn't accepted Jo's invitation and has no care or hosting responsibility involved.</p>`,
      request: 'Will you come over for dinner next Sunday?',
      model: "I've planned a day trip with a friend on Sunday, so I won't be coming to dinner.",
      pushback: "But everyone's coming.",
      repeat: "I know you'd like me there. I'm keeping the plans I've made.",
      ending: "I'm disappointed.",
      note: "Alex acknowledges Jo's wish and keeps the decision without blaming her or promising another visit. Jo remains disappointed; Alex listens.",
      rehearsal: "Alex has already planned a Sunday day trip with a friend and expects to return late. Alex hasn't accepted Jo's dinner invitation; no care or hosting duty is involved.",
      alternative: "I won't be coming to dinner this Sunday",
      choices: [['maybe', "Maybe. Ask me again nearer the time."], ['clear', "I've planned a day trip with a friend on Sunday, so I won't be coming to dinner."], ['blame', "You always expect me to give up my weekends."]],
      feedback: {
        maybe: "This leaves the invitation open. If Alex has decided not to come, naming that decision would be clearer. 'Maybe' fits if Alex is truly unsure.",
        clear: "This states Alex's decision without blaming Jo or inventing an obligation. Jo may still be disappointed. Different words can communicate the same choice.",
        blame: "This adds an accusation. 'Always' isn't a fact in this example. Alex can remove the accusation and state the decision about Sunday."
      },
      branchLabels: [['acceptance', 'Accepts the decision'], ['disappointment', 'Feels disappointed'], ['shorter', 'Suggests a shorter visit']],
      replies: {
        acceptance: ['Okay, thanks for telling me.', '', 'Alex can end the exchange there. No promise of another visit is needed.'],
        disappointment: ["But everyone's coming.", "I know you'd like me there. I'm keeping the plans I've made.", 'Alex acknowledges the wish and keeps the same decision. Jo may remain disappointed.'],
        shorter: ['Could you just come for an hour?', "I won't be back in time for a shorter visit either. I'm keeping the plans I've made.", 'A shorter visit still conflicts with the choice Alex has made. Alex could reconsider if they wanted to; negotiation does not require accepting an unwanted alternative.']
      }
    }
  };
  const example = () => examples[state.context];
  const contextChoice = () => `<fieldset class="choices"><legend>Choose an example</legend>${Object.entries(examples).map(([v,item]) => `<label class="choice"><input type="radio" name="context" value="${v}"${state.context === v ? ' checked' : ''}><span>${item.label}</span></label>`).join('')}</fieldset><p class="small">Both examples practise the same skill. Choose one; you don't need to complete both.${hasNotes() ? ' Changing examples keeps your written notes; you can revise or clear them yourself.' : ''}</p>`;
  const demonstration = () => `<div class="dialogue">${line(example().person,example().request)}<p class="action-note">Alex listens, then takes a moment before answering.</p>${line('Alex',example().model)}${line(example().person,example().pushback)}${line('Alex',example().repeat)}${line(example().person,example().ending)}</div><p>${example().note}</p>`;
  const illustratedExample = () => {if(state.context==='friend')return `<section class="illustrated-example" data-demonstration="friend" aria-label="Animated friend exchange"><p class="demo-moment small">A friend asks for a lift</p><video controls playsinline preload="metadata" aria-label="Play or pause Alex and Sam's exchange"><source src="video/local-animation/friend-narrative.webm?v=9" type="video/webm"><track kind="captions" src="video/local-animation/friend.vtt?v=9" srclang="en" label="English"></video><p class="demo-status small" role="status">Loading the example. You can read the exchange or continue below.</p></section>`;const family=state.context==='family',name=family?'family':'friend',title=family?'A family invitation':'A friend asks for a lift',view=family?'10 668 493 300':'10 323 493 337';return `<section class="illustrated-example" data-demonstration="${name}" aria-label="Illustrated ${name} exchange"><p class="demo-moment small">${title}</p><div class="demo-picture"><svg viewBox="${view}" role="img" aria-label="${family?'Jo invites Alex to dinner; Alex listens during a visit.':'Sam asks; Alex listens outside the apartment entrance.'}" xmlns="http://www.w3.org/2000/svg"><image href="video/three-exchanges-storyboard-v01.png" width="1536" height="1024"/></svg></div><audio preload="none" aria-label="Play or pause the illustrated ${name} exchange"></audio><p class="demo-status small" role="status">Loading the example. You can read the exchange or continue below.</p><div class="demo-caption" role="region" aria-label="Current narration or dialogue"><strong>Ready when you are</strong>Choose Play to hear the exchange.</div></section>`;};
  const fit = () => `<aside class="fit"><h2>Choose a situation that fits</h2><p>Start with a small, optional request you have a choice about. Consider any promises or responsibilities. If you fear threats, coercion or retaliation, use a fictional example, stop, or discuss safer options with a trusted support person or therapist.</p><p>This exercise can't assess your safety or guide you through an abusive or high-stakes situation.</p></aside>`;
  const journey = step => `<ol class="steps" aria-label="Practice steps">${['Choose a situation','Rehearse','Respond','Take it with you'].map((name,i)=>`<li${step === i ? ' aria-current="step"' : ''}>${i+1}. ${name}</li>`).join('')}</ol>`;
  const heading = (title, eyebrow = 'Assertive communication') => `<p class="eyebrow">${eyebrow}</p><h1 tabindex="-1">${title}</h1>`;
  const practiceActions = back => actions(goButton('Back',back),btn('End this practice','finish'));
  const evidence = `<p>Research on longer assertiveness-training programmes suggests benefits for self-reported assertiveness and social anxiety. This brief exercise draws on some of those teaching ideas, but has not been evaluated for effectiveness. It offers rehearsal without a promised outcome.</p><p class="small">The findings concern broader programmes, not this dialogue, response cards or a video. <a href="#sources">Read the sources and their limits</a>.</p>`;
  const field = (key, label, help = '') => `<div class="field"><label for="${key}">${label}</label>${help ? `<span id="${key}-help" class="small">${help}</span>` : ''}<textarea id="${key}" data-field="${key}" maxlength="3000"${help ? ` aria-describedby="${key}-help"` : ''}>${safe(state[key])}</textarea></div>`;
  const sections = [['scenario','My practice scenario'],['wording','My first reply'],['anticipated','A response I considered'],['followup','My follow-up reply'],['words','Words I want to keep'],['difficulty','What felt difficult'],['question','A question for therapy'],['opportunity','A possible next opportunity']];
  const personalResponses = {
    acceptance: ['Accepts the limit', 'Okay, thanks for telling me.', 'You may not need a second reply. You can end the exchange here.'],
    disappointment: ['Shows disappointment', 'Oh. I was hoping you could.', 'You could acknowledge what they wanted and restate your limit.'],
    minimize: ['Suggests it will be quick', "It won't take long. Could you just do this much?", 'Consider whether the smaller request changes what you want. You can keep the limit or reconsider.'],
    obligation: ['Appeals to the relationship', "I thought I could count on you.", 'You can acknowledge the relationship without promising something you do not want to offer.'],
    other: ['A different response', '', 'Write a response that fits your scenario, or just imagine it privately.']
  };
  const hasNotes = () => sections.some(([key]) => state[key].trim() && (key!=='anticipated'||state.personalResponse==='other'));
  const selectedText = () => {
    const kept = sections.filter(([key]) => state.selected.includes(key) && state[key].trim());
    if (!kept.length) return '';
    return 'A Place to Practise — Saying no to an everyday request\nPersonal summary · chosen items only\n\n' + kept.map(([key,label]) => `${label}\n${state[key].trim()}`).join('\n\n') + '\n\nThis file is a personal note, not a clinical assessment. Nothing was sent to a therapist.\n';
  };
  function render() {
    window.PracticeDemonstration?.stop();
    main.className = current === 'intro' ? 'hero' : '';
    let html = '';
    if (current === 'intro') html = `<section class="boundary-native-intro">${heading('Saying no to an everyday request','Communicate a choice')}<p class="lead">Practise declining a small, optional request clearly and respectfully.</p><p>Try a fictional exchange, or rehearse a suitable situation of your own. You can think, speak privately or optionally write.</p>${fit()}${actions(goButton('Start','practise',true))}<details><summary>Optional guide and worked examples</summary>${heading('A choice you can communicate')}<p class="lead">Assertive communication means expressing your needs, preferences or limits clearly and respectfully.</p><p>A boundary communicates your choice. It doesn't control the other person's response. You can give a short, honest reason if you want to; you don't need to invent an urgent obligation to explain your choice.</p><p>Offer another option only if you want to and can follow through. You don't have to feel completely confident to rehearse your words.</p><h2>Choose an example</h2>${contextChoice()}${example().scenario}<div class="card"><p><strong>A limit:</strong> say what you mean clearly.</p><p><strong>A reason, if you want:</strong> keep it short and honest.</p><p><strong>If asked again:</strong> acknowledge, repeat, reconsider or end the exchange as the situation calls for.</p></div><p class="small muted">This is a fictional exchange, not a prediction. Take a moment before answering if you want to; there is no prescribed pause, gesture or eye contact.</p><details><summary>What is this based on?</summary>${evidence}</details>${actions(goButton('See the exchange','example',true),goButton('Try the practice','practise'),goButton('Back','intro'))}</details><p class="small">Your notes stay only in this open practice. Leaving or refreshing clears them. Download chosen notes if you want a copy. My Toolbox saves the tool shortcut, not your answers.</p></section>`;
    if (current === 'learn') html = `${heading('A choice you can communicate')}<p class="lead">Assertive communication means expressing your needs, preferences or limits clearly and respectfully.</p><p>A boundary communicates your choice. It doesn't control the other person's response. You can give a short, honest reason if you want to; you don't need to invent an urgent obligation to explain your choice.</p><p>Offer another option only if you want to and can follow through. You don't have to feel completely confident to rehearse your words.</p><h2>Choose an example</h2>${contextChoice()}${example().scenario}<div class="card"><p><strong>A limit:</strong> say what you mean clearly.</p><p><strong>A reason, if you want:</strong> keep it short and honest.</p><p><strong>If asked again:</strong> acknowledge, repeat, reconsider or end the exchange as the situation calls for.</p></div><p class="small muted">This is a fictional exchange, not a prediction. Take a moment before answering if you want to; there is no prescribed pause, gesture or eye contact.</p><details><summary>What is this based on?</summary>${evidence}</details>${actions(goButton('See the exchange','example',true),goButton('Try the practice','practise'),goButton('Back','intro'))}`;
    if (current === 'practise') html = `${journey(0)}${heading('Choose where to start')}${fit()}<fieldset class="choices"><legend>Your practice situation</legend>${[['fictional','Use a fictional example','Choose a friend or family exchange below.'],['personal','Use my own or a hypothetical situation','Describe a scenario and draft two replies, or rehearse entirely in your mind.']].map(([v,label,help])=>`<label class="choice"><input type="radio" name="mode" value="${v}"${state.mode === v ? ' checked' : ''}><span>${label}<span class="small">${help}</span></span></label>`).join('')}</fieldset>${state.mode === 'fictional' ? contextChoice() : ''}<p class="small">The other person may accept, feel disappointed or ask again. Choose a suitable moment; this practice doesn't promise how they'll respond.</p>${actions(btn('Continue','start',true),goButton('Read the lesson','learn'),btn('End this practice','finish'))}`;
    if (current === 'choose') html = `${journey(0)}${heading('What makes the limit clear?')}${example().scenario}<fieldset class="choices"><legend>Explore a possible reply from Alex</legend>${example().choices.map(([v,label])=>`<label class="choice"><input type="radio" name="choice" value="${v}"${state.choice === v ? ' checked' : ''}><span>${label}</span></label>`).join('')}</fieldset>${actions(btn('See how this wording works','explain'),goButton('Continue to rehearsal','rehearse',true))}<div id="feedback" class="feedback" role="status">${state.showFeedback && state.choice ? `<p>${example().feedback[state.choice]}</p>` : ''}</div><p class="small muted">You can continue after any reply or skip choosing. There is no score.</p>${practiceActions('practise')}`;
    if (current === 'rehearse') html = `${journey(1)}${heading('Try the words privately')}${state.mode === 'fictional' ? `<p>${example().rehearsal}</p><div class="dialogue">${line(example().person,example().request)}${line('Alex',example().model)}</div><p>Use this wording or try your own. “${example().alternative}” is another option.</p>` : `<p>Think of a small optional request and what you want to say. You can keep the situation entirely in your mind.</p><div class="card"><p><strong>Name the limit:</strong> “I'm not available for that tonight.”</p><p><strong>A reason, if you want:</strong> “I'm having an evening at home.”</p><p>Change the request and context to fit what you actually mean. Don't add a future offer unless it's wanted and realistic.</p></div>`}<p>Say it aloud off-device, think the words, or read the example. Nothing is recorded. You can take a moment if you want.</p><details id="writing"${state.writingOpen ? ' open' : ''}><summary>Write my wording instead (optional)</summary>${field('wording','My wording','Use only what you want to include. No names or identifying details are needed. Up to 3,000 characters; this is not graded.')}</details><details><summary>A private check</summary><p>Does this say what I mean? Is any offer realistic? Is this a suitable situation to try?</p></details>${actions(goButton(state.mode === 'fictional' ? 'Explore a response' : 'See possible responses','response',true),goButton('Skip to everyday use','everyday'))}${practiceActions(state.mode === 'fictional' ? 'choose' : 'practise')}`;
    if (current === 'response') html = `${journey(2)}${heading('If they respond…')}<p>${state.mode === 'personal' ? 'The other person might respond differently. Use the selected fictional example to explore a possibility, or skip this part.' : `${example().person} has heard Alex decline. Explore one possible response.`}</p><fieldset class="choices"><legend>Choose a possibility to explore</legend>${example().branchLabels.map(([v,label])=>`<label class="choice"><input type="radio" name="branch" value="${v}"${state.branch === v ? ' checked' : ''}><span>${label}</span></label>`).join('')}</fieldset>${actions(btn('Read a possible exchange','show-response'),goButton('Continue to everyday use','everyday',true))}<div id="response-feedback" class="feedback" role="status">${state.showResponse && state.branch ? responseMarkup() : ''}</div><details><summary>If it turns into pressure</summary><p>You don't have to keep rehearsing or keep repeating a refusal. You can end this practice. In life, whether to continue, leave or seek support depends on the situation; this exercise can't determine what is safe for you.</p></details>${practiceActions('rehearse')}`;
    if (current === 'everyday') html = `${journey(3)}${heading('Take one small idea with you')}<p class="lead">Consider a small, optional request where you have a choice.</p><p>For example, declining a non-urgent favour or an invitation you haven't accepted. Consider any commitments or responsibilities before choosing a limit. Rehearse first if you want, and decide whether the situation and timing fit.</p><p>Afterwards, you might notice what you communicated and what happened separately. Disappointment alone doesn't mean you communicated badly.</p><div class="card"><p><strong>A limit:</strong> what I'm available for.</p><p><strong>An optional reason:</strong> short and honest.</p><p><strong>A follow-up:</strong> repeat, reconsider, or end the exchange as the situation calls for.</p></div><p>No real-life task is assigned. You can finish here, return another time or keep an optional note.</p>${actions(btn('Finish and clear','finish',true),goButton('Optional reflection','reflection'),btn('Practise again','repeat'))}${actions(goButton('Back','response'))}`;
    if (current === 'reflection') html = `${journey(3)}${heading('Keep what matters to you','Optional reflection')}<p>You can think about any of these privately, write a little, or skip them all. These are personal prompts, not assessment questions.</p>${field('words','Words I want to keep')}${field('difficulty','What felt difficult, if anything')}${field('question','A question I might bring to therapy')}${field('opportunity','A small opportunity I might consider')}<p class="small">Nothing is sent or monitored. To keep a copy, select items and preview them first.</p>${actions(goButton('Choose what to keep','summary',true),btn('Finish and clear','finish'),goButton('Back','everyday'))}`;
    if (current === 'example') html = `${heading('See the exchange','Example · An everyday refusal')}<p class="lead">Notice what Alex communicates and how the other person responds.</p>${contextChoice()}${example().scenario}${state.context==='family' ? `<h2>The conversation</h2>${demonstration()}<h2>Hear and see the exchange</h2>${illustratedExample()}` : `${illustratedExample()}<details><summary>Read the exchange instead</summary>${demonstration()}</details>`}<div class="card"><h2>What did Alex make clear?</h2><p>Alex acknowledges the other person's wish and keeps the same limit. Disappointment can remain after a clear response.</p><p>Your words can be different. A particular gesture, gaze or pause is not required.</p></div>${actions(goButton('Try the practice','practise',true),goButton('Back','learn'))}`;
    if (current === 'rehearse' && state.mode==='personal') html = `${journey(1)}${heading('Your situation. Your first reply.')}<p class="lead">Choose a hypothetical or likely small, optional request where you have a choice.</p><p>Consider any promises or responsibilities. You can write below, think through the exchange privately, or speak the words off-device. No writing is required.</p>${field('scenario','My practice scenario (optional)','What might they ask, and what do you want to communicate? No names or identifying details are needed.')}${field('wording','My first reply (optional)','State the limit in words that fit you. Add a short, honest reason only if you want to.')}<details><summary>A starting point, if useful</summary><p>“I'm not available for that tonight.”</p><p>Change the words to fit what you actually mean. Add another option only if you want to and can follow through.</p></details><p class="small">Your writing stays in this page until you clear, finish, restart or leave. Nothing is recorded or graded.</p>${actions(goButton('Consider a response','response',true),goButton('Skip to everyday use','everyday'))}${practiceActions('practise')}`;
    if (current === 'response' && state.mode==='personal') html = `${journey(2)}${heading('A possible response. Your next reply.')}<p>Choose one response to rehearse, or skip choosing. These are possibilities, not predictions about the person in your scenario.</p>${state.scenario.trim()||state.wording.trim()?`<details><summary>Review my scenario and first reply</summary>${state.scenario.trim()?`<p><strong>Scenario:</strong> ${safe(state.scenario)}</p>`:''}${state.wording.trim()?`<p><strong>My first reply:</strong> ${safe(state.wording)}</p>`:''}</details>`:''}<fieldset class="choices"><legend>A response I might hear</legend>${Object.entries(personalResponses).map(([v,item])=>`<label class="choice"><input type="radio" name="personal-response" value="${v}"${state.personalResponse===v?' checked':''}><span>${item[0]}${item[1]?`<span class="small">“${safe(item[1])}”</span>`:''}</span></label>`).join('')}</fieldset>${state.personalResponse==='other'?field('anticipated','Their possible response (optional)','Use your own words, or keep the response in mind.'):state.personalResponse?`<div class="card"><p>${personalResponses[state.personalResponse][2]}</p></div>`:''}${field('followup','My follow-up reply (optional)','What might you say next? You can acknowledge, repeat, reconsider or end the exchange. A second reply is not always needed.')}<p class="small">Changing the response keeps your follow-up wording; review it to see whether it still fits.</p><details><summary>If it turns into pressure</summary><p>You do not have to continue the exchange or keep repeating a refusal. This exercise cannot determine what is safe in your situation.</p></details>${actions(goButton('Continue to everyday use','everyday',true))}${practiceActions('rehearse')}`;
    if (current === 'summary') {
      const available = sections.filter(([key])=>state[key].trim());
      html = `${heading('Choose your local copy','Optional personal summary')}<p>Only checked items will be included. Nothing is selected automatically.</p>${available.length ? `<fieldset class="choices"><legend>Items to include</legend><div class="checks">${available.map(([key,label])=>`<label><input type="checkbox" name="export" value="${key}"${state.selected.includes(key) ? ' checked' : ''}>${label}</label>`).join('')}</div></fieldset>` : '<p>No written items have been added. You can finish without a copy, or return to optional reflection.</p>'}<h2>Preview</h2><pre id="preview" class="preview">${safe(selectedText() || 'No items selected.')}</pre><p class="small">Download a plain-text copy to keep or bring to therapy through a channel you choose. Downloads persist after this session clears; your device or cloud-sync settings may sync them.</p>${actions(`<button id="save" data-action="save" class="primary"${selectedText() ? '' : ' disabled'}>Download chosen items (.txt)</button>`,btn('Finish and clear','finish'),btn('Practise again','repeat'),goButton('Back to reflection','reflection'))}<p id="save-status" role="status"></p>`;
    }
    if (current === 'complete') html = `${heading('Your session is cleared')}<p>Your wording, reflections and choices have been removed from this page. Any copy you downloaded remains on your device.</p><p>There is no score or requirement to do more. Return when it would be useful.</p>${actions(goButton('Practise again','practise',true),goButton('Read the lesson','learn'),goButton('Home','intro'))}`;
    if (current === 'sources') html = `${heading('Sources, with their limits','Evidence & adaptation')}<p>This is an original, brief teaching adaptation. It has not been evaluated for effectiveness or clinically signed off. A source review is not clinical approval.</p>${evidence.replace('<p class="small">The findings concern broader programmes, not this dialogue, response cards or a video. <a href="#sources">Read the sources and their limits</a>.</p>','')}<ol class="sources"><li><a href="https://www.cci.health.wa.gov.au/Resources/Looking-After-Yourself/Assertiveness" target="_blank" rel="noopener noreferrer">CCI: Assert Yourself! (2008)</a><br>Government of Western Australia education. Modules 1 and 6 inform clear, respectful refusals, contextual choice and possible repetition. These are teaching techniques, not isolated efficacy findings.</li><li><a href="https://pubmed.ncbi.nlm.nih.gov/37273933/" target="_blank" rel="noopener noreferrer">Hagberg et al. (2023): adult randomized trial</a><br>An eight-week internet CBT programme improved self-reported adaptive assertiveness versus wait-list. Multiple components, a self-selected Swedish sample and no active comparator limit transfer to this exercise.</li><li><a href="https://link.springer.com/article/10.1007/s41042-026-00297-7" target="_blank" rel="noopener noreferrer">Hede, Malouff &amp; Meynadier (2026): social anxiety meta-analysis</a><br>12 trials of programmes involving 4–12 sessions. Findings suggest social-anxiety benefit, with self-report, varied populations, heterogeneity and limited follow-up. They do not establish effects from a few-minute exercise or equivalence to other therapies.</li><li><a href="https://bc.cmha.ca/documents/stress/" target="_blank" rel="noopener noreferrer">CMHA British Columbia: Stress</a><br>Canadian education describes respectful assertion as a coping skill. It is not evidence that this module reduces stress.</li></ol><p>All dialogue, response-card feedback and reflection prompts are original. No questionnaire score, diagnostic interpretation or guarantee of better friendships is offered. Accessible participation alternatives have not been shown to produce equivalent outcomes.</p><p class="small muted">Source audit: 4 October 2026. Detailed claim-by-claim research is in the project review records. Source links open new tabs only when you choose them.</p>${actions(goButton('Back to practice','practise'),goButton('Home','intro'))}`;
    if (current === 'clinician') html = `${heading('Introduce an everyday refusal','For therapists · review edition')}<p class="lead">Goal: rehearse one specific, respectful refusal of an optional request and consider a response if asked again.</p><p>Initial design context: therapist-supported adults. Discuss whether this small, discretionary situation fits the person's circumstances, communication preferences and safety. Fictional reading or private mental rehearsal avoids disclosure.</p>${fit()}<h2>What this version teaches</h2><p>One refusal skill with two optional contexts: a friend asks for a lift, or a family member invites an adult to dinner. Teach a clear limit, an optional honest reason and a possible response if asked again; no unwanted alternative offer is required. It does not teach abuse safety planning, conflict resolution in every context, or a complete CBT/DBT programme.</p><h2>Place within assertive communication</h2><p>This is focused practice for one everyday refusal. It is not a complete assertiveness programme. Workload and priority negotiation belongs in the separately planned “Asking for a workable plan” exercise.</p><h2>What to review</h2><p>Clinical suitability and script review, relevance to people who don't drive, actual mobile devices, screen-reader use and unfamiliar-user comprehension remain pending. Record reviewer, role, version, date and disposition before client use.</p><h2>Client-controlled sharing</h2><p>There are no accounts, assigned tasks, monitoring or automatic messages. Optional selected notes download as text. A client may bring or send their own file through an independently agreed channel.</p><p>The teaching card includes a QR code and public link to this review edition. The optional two-page download adds an offline practice sheet; clinical sign-off remains pending.</p>${actions(goButton('Learn path','learn'),goButton('Repeat-practice path','practise'),goButton('Sources and limitations','sources'))}<p class="small muted">Module 0.7-review · 4 October 2026 · clinical sign-off pending.</p>`;
    main.innerHTML = html;
    main.dataset.route = current;
    const media=main.querySelector('[data-demonstration]');if(media)window.PracticeDemonstration.mount(media);
    main.querySelector('h1')?.focus({preventScroll:true});
    window.scrollTo(0,0);
  }
  function responseMarkup() {
    const [other,alex,note] = example().replies[state.branch];
    return `<div class="dialogue">${line(example().person,other)}${alex ? line('Alex',alex) : ''}</div><p>${note}</p>`;
  }
  function revokeDownloads() { for (const url of downloadURLs) URL.revokeObjectURL(url); downloadURLs.clear(); }
  function clearState() { window.PracticeDemonstration?.stop();state = empty(); revokeDownloads(); main.replaceChildren(); }
  function navigate(route) { if (location.hash === `#${route}`) { current=route;render(); } else location.hash=route; }
  function promptReset(destination) {
    resetDestination = destination;
    if (destination === 'complete' && !hasNotes()) { clearState();navigate('complete');return; }
    returnFocus = document.activeElement;
    document.querySelector('#reset-title').textContent = destination === 'practise' ? 'Start a fresh practice?' : 'Clear this session?';
    document.querySelector('#reset-description').textContent = 'Your wording, notes and choices will be cleared. You can review a local copy first. Downloaded copies will remain on your device.';
    document.querySelector('#review-keep').hidden = !hasNotes();
    document.querySelector('#confirm-reset').textContent = destination === 'practise' ? 'Clear and start again' : 'Clear and finish';
    if(parent!==window)parent.postMessage({boundaryNative:1,type:'confirm',title:document.querySelector('#reset-title').textContent,confirmLabel:document.querySelector('#confirm-reset').textContent,canReview:hasNotes()},location.origin);else{dialog.showModal();document.querySelector('#cancel-reset').focus();}
  }
  function cancelReset() { hostExitAfterFinish=null;dialog.close();returnFocus?.focus({preventScroll:true}); }
  main.addEventListener('input',event=>{ const key=event.target.dataset.field;if(sections.some(([k])=>key===k)) state[key]=event.target.value; });
  main.addEventListener('toggle',event=>{if(event.target.id==='writing')state.writingOpen=event.target.open;},true);
  main.addEventListener('change',event=>{
    const el=event.target;
    if(el.name==='mode'){
      state.mode=el.value;render();main.querySelector(`input[name="mode"][value="${state.mode}"]`)?.focus();
    }
    if(el.name==='context' && Object.hasOwn(examples,el.value)){
      state.context=el.value;state.choice='';state.branch='';state.showFeedback=false;state.showResponse=false;
      render();main.querySelector(`input[name="context"][value="${state.context}"]`)?.focus();
    }
    if(el.name==='choice'){state.choice=el.value;state.showFeedback=false;document.querySelector('#feedback').replaceChildren();}
    if(el.name==='branch'){state.branch=el.value;state.showResponse=false;document.querySelector('#response-feedback').replaceChildren();}
    if(el.name==='personal-response' && Object.hasOwn(personalResponses,el.value)){state.personalResponse=el.value;state.anticipated=personalResponses[el.value][1];render();main.querySelector(`input[name="personal-response"][value="${el.value}"]`)?.focus();}
    if(el.name==='export'){
      state.selected=Array.from(main.querySelectorAll('input[name="export"]:checked'),input=>input.value);
      document.querySelector('#preview').textContent=selectedText()||'No items selected.';
      document.querySelector('#save').disabled=!selectedText();
      document.querySelector('#save-status').textContent='';
    }
  });
  main.addEventListener('click',event=>{
    const action=event.target.closest('[data-action]')?.dataset.action;if(!action)return;
    if(action.startsWith('go:')){navigate(action.slice(3));return;}
    if(action==='start'){navigate(state.mode==='fictional'?'choose':'rehearse');return;}
    if(action==='finish'){promptReset('complete');return;}
    if(action==='repeat'){promptReset('practise');return;}
    if(action==='explain'){
      state.showFeedback=!!state.choice;
      document.querySelector('#feedback').innerHTML=`<p>${state.choice?example().feedback[state.choice]:'Choose a reply if you want an explanation, or continue without choosing.'}</p>`;return;
    }
    if(action==='show-response'){
      state.showResponse=!!state.branch;
      document.querySelector('#response-feedback').innerHTML=state.branch?responseMarkup():'<p>Choose a possibility to read, or continue without choosing.</p>';return;
    }
    if(action==='save'){
      const text=selectedText();if(!text)return;
      const status=document.querySelector('#save-status');
      try{
        revokeDownloads();
        const url=URL.createObjectURL(new Blob([text],{type:'text/plain;charset=utf-8'}));downloadURLs.add(url);
        const link=document.createElement('a');link.href=url;link.download='Practice-Room-small-boundary-summary.txt';document.body.append(link);link.click();link.remove();
        status.textContent='Download requested. Check your browser downloads; you decide whether to share the file.';
        setTimeout(()=>{URL.revokeObjectURL(url);downloadURLs.delete(url);},1000);
      }catch{status.textContent="The download couldn't be prepared. You can select and copy your preview text instead.";}
    }
  });
  document.querySelector('#clear').addEventListener('click',()=>promptReset('complete'));
  document.querySelector('#confirm-reset').addEventListener('click',()=>{dialog.close();clearState();if(hostExitAfterFinish){const target=hostExitAfterFinish;hostExitAfterFinish=null;parent.postMessage({boundaryNative:1,type:'exit',target},location.origin);}else navigate(resetDestination);});
  document.querySelector('#cancel-reset').addEventListener('click',cancelReset);
  document.querySelector('#review-keep').addEventListener('click',()=>{hostExitAfterFinish=null;dialog.close();navigate('summary');});
  dialog.addEventListener('cancel',event=>{event.preventDefault();cancelReset();});
  dialog.addEventListener('keydown',event=>{
    if(event.key!=='Tab')return;
    const controls=Array.from(dialog.querySelectorAll('button')).filter(el=>!el.hidden&&!el.disabled);
    const first=controls[0],last=controls.at(-1);
    if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
  });
  document.querySelector('#boundary-host-exit').addEventListener('click',()=>{if(parent===window){promptReset('complete');return;}if(hasNotes()){hostExitAfterFinish='tools-index';promptReset('complete');}else{clearState();parent.postMessage({boundaryNative:1,type:'exit',target:'tools-index'},location.origin);}});
  addEventListener('message',e=>{if(e.origin!==location.origin||e.source!==parent||e.data?.boundaryNative!==1)return;const d=e.data;if(d.type==='decision'){const id={clear:'confirm-reset',cancel:'cancel-reset',keep:'review-keep'}[d.choice];if(id)document.getElementById(id)?.click();}if(d.type==='pause')pauseNativeMedia();if(d.type==='theme'){document.documentElement.dataset.hostTheme=d.theme;document.documentElement.style.fontSize=d.font+'px';}});
  new MutationObserver(()=>{if(parent!==window)parent.postMessage({boundaryNative:1,type:'stage',stage:current},location.origin);}).observe(main,{childList:true});
  window.addEventListener('hashchange',()=>{
    const route=location.hash.slice(1);
    if(route==='main'){main.focus();return;}
    if(!routes.has(route)){history.replaceState(null,'','#intro');current='intro';}else current=route;
    if(current==='choose' && state.mode==='personal')current='rehearse';
    if(current==='complete')clearState();
    render();
  });
  function pauseNativeMedia(){document.querySelectorAll('audio,video').forEach(media=>media.pause());}
  document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseNativeMedia();});
  document.addEventListener('freeze',pauseNativeMedia);
  window.addEventListener('pagehide',()=>{dialog.close();clearState();});
  window.addEventListener('pageshow',event=>{
    if(event.persisted){clearState();current='intro';history.replaceState(null,'','#intro');render();}
  });
  // Only generic route names are supported; discard incoming query parameters.
  const initial=location.hash.slice(1);
  current=routes.has(initial)?initial:'intro';
  history.replaceState(null,'',location.pathname+'#'+current);
  render();
})();





