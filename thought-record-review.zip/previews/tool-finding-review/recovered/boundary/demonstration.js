'use strict';
(() => {
  const files={
    'original-sheet.png':'video/three-exchanges-storyboard-v01.png',
    'friend-nuance-sheet.png':'video/friend-nuance-storyboard-v02.png',
    'family-nuance-sheet.png':'video/family-nuance-storyboard-v01.png'
  };
  const escape=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const svg=c=>`<svg viewBox="${escape(c.view)}" preserveAspectRatio="xMidYMid slice" role="img" aria-label="${escape(c.alt)}" xmlns="http://www.w3.org/2000/svg"><image href="${files[c.source]}" width="${c.width}" height="${c.height}"/></svg>`;
  let dispose=()=>{};
  window.PracticeDemonstration={
    stop(){dispose();dispose=()=>{};},
    mount(root){
      this.stop();
      const video=root.querySelector('video');
      if(video){
        const status=root.querySelector('.demo-status');
        dispose=()=>{video.pause();video.removeAttribute('src');video.querySelectorAll('source').forEach(source=>source.removeAttribute('src'));video.load();};
        const loaded=()=>{root.dataset.ready='true';status.textContent=`About ${Math.round(video.duration)} seconds. Play, pause or skip the example whenever you want.`;};
        if(video.readyState>=1)loaded();else video.addEventListener('loadedmetadata',loaded,{once:true});
        const failed=()=>{status.textContent='The video could not load. Read the exchange below or continue to practice.';video.hidden=true;};
        video.addEventListener('error',failed,{once:true});video.querySelector('source')?.addEventListener('error',failed,{once:true});
        return;
      }
      const context=root.dataset.demonstration==='family'?'family':'friend';
      const cardFile=context==='family'?'family-storyboard-cards.json':'storyboard-cards.json';
      const controller=new AbortController();let destroyed=false,blobURL=null,cards=[],timeline=[];
      const audio=root.querySelector('audio'),picture=root.querySelector('.demo-picture'),caption=root.querySelector('.demo-caption'),status=root.querySelector('.demo-status'),moment=root.querySelector('.demo-moment');
      dispose=()=>{destroyed=true;controller.abort();audio.pause();audio.removeAttribute('src');audio.load();if(blobURL)URL.revokeObjectURL(blobURL);};
      const show=()=>{
        if(destroyed||!cards.length)return;
        const t=audio.currentTime,index=Math.max(0,cards.findLastIndex(c=>t>=c.start)),card=cards[index],cue=timeline.find(c=>t>=c.start&&t<c.end);
        if(picture.dataset.card!==String(index)){picture.innerHTML=svg(card);picture.dataset.card=String(index);}
        moment.textContent=`${index+1} of ${cards.length} · ${card.title}`;
        const name=document.createElement('strong');name.textContent=cue?.speaker||(t===0?'Ready when you are':'A moment between replies');
        caption.replaceChildren(name,document.createTextNode(cue?.text||(t===0?'Choose Play to hear the exchange.':t>=audio.duration-.5?'What words would feel natural for you?':'')));
      };
      const get=async(name,kind='json')=>{const r=await fetch(name,{signal:controller.signal});if(!r.ok)throw Error('Unavailable demonstration asset');return r[kind]();};
      Promise.all([get('video/local-animation/'+cardFile),get('video/local-animation/timeline.json'),get('video/local-animation/assets/'+context+'-narrative.wav','blob')]).then(([items,story,track])=>{
        if(destroyed)return;
        if(items.length!==9||items.some(c=>!files[c.source]))throw Error('Unexpected illustration set');
        cards=items;timeline=story[context].timeline;
        audio.addEventListener('loadedmetadata',()=>{
          if(destroyed)return;
          root.dataset.ready='true';audio.controls=true;
          status.textContent=`About ${Math.round(audio.duration)} seconds. Play, pause or skip the example whenever you want.`;
          show();
        },{once:true});
        blobURL=URL.createObjectURL(track);audio.src=blobURL;
      }).catch(error=>{if(destroyed||error.name==='AbortError')return;status.textContent='The illustrated audio could not load. Read the exchange below or continue to practice.';audio.hidden=true;});
      audio.addEventListener('timeupdate',show);audio.addEventListener('seeked',show);audio.addEventListener('ended',show);
    }
  };
})();

