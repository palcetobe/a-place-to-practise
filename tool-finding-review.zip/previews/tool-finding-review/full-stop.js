/* Original A Place to Practise explanation of DBT STOP. Optional notes are
 * page-memory only. No recording, generated advice, timer or remote sender. */
(()=>{'use strict';
const root=document.getElementById('full-stop');if(!root)return;
const node=(t,text)=>{const n=document.createElement(t);if(text!==undefined)n.textContent=text;return n};
const button=(label,fn)=>{const b=node('button',label);b.type='button';b.onclick=fn;return b};
const parts=[
 {letter:'S',name:'Stop',guide:'Pause the action you are about to take. For example, leave a message unsent or put down what is in your hand. You do not have to stop having the feeling.',prompt:'What action would you pause right now?'},
 {letter:'T',name:'Take a step back',guide:'Give yourself a little distance before deciding. You could look away from the screen, put your phone aside, or pause the conversation if it is safe to do so. There is no required movement or breathing pattern.',prompt:'What would give you a little space to choose?'},
 {letter:'O',name:'Observe',guide:'Notice what is happening around you and within you: the facts you know, what you are thinking, your feelings and the urge to act. Keep what you know separate from what you are guessing. You can still be unsure.',prompt:'What do you notice? What do you know, and what is still uncertain?'},
 {letter:'P',name:'Proceed mindfully',guide:'Consider what matters now and what could follow from the options available. Choose a response that fits the situation and your priorities. That could mean acting firmly, waiting, changing direction or getting support.',prompt:'What matters now? Which response would fit, and what might happen next?'}
];
let stage='intro',at=0,notes=['','','',''],selected=new Set(),reflection=null;
const body=root.querySelector('.stop-body'),status=root.querySelector('.stop-status');
function wipe(){notes=['','','',''];selected.clear();reflection=null;at=0;stage='intro';}
function active(){return window.MMRoutes?.parse(location.hash).route.passageId==='full-stop';}
function route(p,c){window.MMNavigation.openTarget(p,c);}
function save(){const existing=tbLoad().some(e=>e.p==='full-stop'&&!e.c);const result=existing?'saved':tbToggle('full-stop',null);status.textContent=result==='error'?"The shortcut couldn't be saved. Your notes are still here.":'STOP is in My Toolbox. This saves the tool, not your notes.';}
function next(label,fn){const b=button(label,fn);b.className='choice';return b;}
function heading(title){const h=node('h3',title);h.tabIndex=-1;body.append(h);h.focus({preventScroll:true});}
function go(newStage){stage=newStage;render();}
function end(){stage='reflection';render();}
function actions(...items){const d=node('div');d.className='stop-actions';d.append(...items);return d;}
function readGuide(){const details=node('details'),summary=node('summary','Read the four parts');details.append(summary);for(const p of parts)details.append(node('h4',p.letter+' — '+p.name),node('p',p.guide));return details;}
function example(){const d=node('details');d.className='stop-example';d.append(node('summary','See a worked example'),node('p','A volunteer coordinator changes your shift at short notice. You start typing, “Fine, find someone else.” You want your time to be respected, and you do not want to agree to a shift you cannot cover.'));
 for(const [h,t] of [
 ['Stop','You leave the reply unsent. The feeling and the decision are still there.'],
 ['Take a step back','You put the phone down for a moment so you can look at the request again.'],
 ['Observe','The message asks you to change an agreed time. You feel tense and irritated. “They expect me to do everything” is your interpretation. You know you cannot cover the new time; you do not yet know why it changed.'],
 ['Proceed mindfully','One option is a clear limit: “I can do the time we agreed, but I cannot cover the new shift.” It protects your availability and gives the coordinator a clear answer. They may still be disappointed.'],
 ['Another reasonable option','If you need to check your availability, you could say, “I need to check before I agree. I can reply this evening.” That allows time to decide, but it also delays the answer. If the request is urgent, say clearly that you cannot confirm now.']])d.append(node('h4',h),node('p',t));
 d.append(node('p','The skill is noticing the situation and making a considered choice. It does not promise that the other person will agree or that the feeling will go away.'));return d;}
function exportText(){return parts.map((p,i)=>selected.has(i)&&notes[i].trim()?p.name+'\n'+notes[i].trim():null).filter(Boolean).join('\n\n');}
function render(){body.replaceChildren();status.textContent='';
 if(stage==='intro'){
  heading('A pause before your next action');body.append(node('p','Use STOP when a strong urge is pushing you toward an action you want to think through. The four parts help you pause, notice and choose what to do next.'),node('p','If you are in danger, getting to safety or seeking urgent help comes first. You do not need to finish an exercise before getting help.'),example(),readGuide(),node('p','You can think the prompts through, say your response privately or make optional notes. Notes stay only in this open practice; leaving or refreshing clears them. My Toolbox saves a shortcut, not your notes.'),actions(next('Start',()=>{at=0;go('practice');}),button('Back to Help me settle',()=>route('overwhelmed'))));
 }else if(stage==='practice'){
  const p=parts[at];heading(p.letter+' — '+p.name);body.append(node('p','Part '+(at+1)+' of 4'),node('p',p.guide),node('p',p.prompt));const label=node('label','Optional note'),ta=node('textarea');ta.id='stop-note';ta.rows=4;ta.maxLength=1500;ta.value=notes[at];label.htmlFor=ta.id;ta.oninput=()=>{notes[at]=ta.value;};body.append(label,ta,node('p','You can continue without typing.'),actions(button('Back',()=>{if(at){at--;render()}else go('intro')}),next(at===3?'Finish this practice':'Next',()=>{if(at===3)end();else{at++;render()}}),button('Finish for now',end)),readGuide());
 }else if(stage==='reflection'){
  heading('What was this like?');body.append(node('p','You can skip this. There is no required change in how you feel.'));const choices=node('div');choices.className='stop-actions';for(const label of ['Helpful','No change','Unsure','Uncomfortable','Skip']){const b=button(label,()=>{reflection=label;render()});b.setAttribute('aria-pressed',String(reflection===label));choices.append(b)}body.append(choices);if(reflection)body.append(node('p',reflection==='Uncomfortable'?'You have stopped. Choose another approach, get support or finish.':'Choose what you would like to do next.'),actions(button('Repeat',()=>{at=0;go('practice')}),button('Save this tool',save),button('Choose what to keep',()=>go('keep')),button('Try another tool',()=>route('tools-index')),button('Finish',()=>goStartOver())));
 }else if(stage==='keep'){
  heading('Choose notes to keep');body.append(node('p','Nothing is selected automatically. A downloaded file stays where you save it; clearing the page does not remove that file.'));const available=parts.map((p,i)=>({p,i})).filter(x=>notes[x.i].trim());for(const {p,i}of available){const label=node('label'),input=node('input');input.type='checkbox';input.checked=selected.has(i);input.onchange=()=>{input.checked?selected.add(i):selected.delete(i);preview.textContent=exportText()||'No notes selected.';download.disabled=!exportText()};label.append(input,document.createTextNode(p.name));body.append(label)}if(!available.length)body.append(node('p','There are no written notes. You can finish without a file.'));const preview=node('pre',exportText()||'No notes selected.');preview.id='stop-export-preview';const download=button('Download chosen notes (.txt)',()=>{const text=exportText();if(!text)return;const url=URL.createObjectURL(new Blob(['A Place to Practise — STOP\nChosen practice notes\n\n'+text],{type:'text/plain;charset=utf-8'}));const a=node('a');a.href=url;a.download='STOP-chosen-notes.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)});download.disabled=!exportText();body.append(preview,actions(download,button('Back',()=>go('reflection')),button('Finish and clear these notes',()=>{wipe();goStartOver()})));
 }
}
function onRoute(){if(active()){wipe();render()}else{wipe();body.replaceChildren();status.textContent=''}}
addEventListener('mm:routechange',onRoute);addEventListener('pagehide',()=>{wipe();body.replaceChildren()});addEventListener('pageshow',e=>{if(e.persisted)onRoute()});const clear=window.mmClearAppData;if(typeof clear==='function')window.mmClearAppData=function(){wipe();render();return clear.apply(this,arguments)};
const extract=window.tbExtractBlocks;window.tbExtractBlocks=function(entry){if(entry?.p==='full-stop')return[{type:'para',text:'STOP: pause before an impulsive action. Seek safety or urgent help first when needed.'},...parts.flatMap(p=>[{type:'heading',text:p.name},{type:'para',text:p.guide}]),{type:'para',text:'Think, speak privately or optionally write. No required improvement. My Toolbox saves the tool shortcut, not practice notes.'}];return extract(entry)};
window.FullSTOP=Object.freeze({state:()=>({stage,part:at+1,hasNotes:notes.some(x=>x.trim()),reflection}),reset:()=>{wipe();if(active())render()}});onRoute();
})();
