/* Provisional review narration. No user writing, Web Speech, or per-label requests. */
(function () {
  'use strict';
  const BANK_URL = 'assets/selection-audio/generic-label-bank.wav';
  let provider = null, current = null, key = '', revision = 0;
  let context = null, bankPromise = null, merged = null, source = null;
  let startedAt = 0, offset = 0, phase = 'Off', panel = null;
  let stateNode, transcriptNode, noticeNode, listen, pause, stopButton;
  const normalize = value => String(value).trim().toLowerCase().replace(/\s+/g, ' ');
  const manifest = () => window.PPSelectionBank;
  function snapshot() {
    const input = provider ? provider() : { active: false };
    if (!input || !input.active) return { active: false, builtins: [], customCount: 0 };
    const builtins = Array.isArray(input.builtins) ? input.builtins.map(normalize) : [];
    const customCount = Math.max(0, Math.floor(Number(input.customCount) || 0));
    const allowed = (input.mode === 'checkin' && input.step === 3) || (input.mode === 'distress' && input.step === 4);
    return { active: allowed, mode: input.mode, step: input.step, builtins, customCount, revision: input.revision || 0 };
  }
  function paint(value) {
    phase = value;
    if (!panel) return;
    stateNode.textContent = value;
    listen.textContent = value === 'Paused' ? 'Resume selections' : value === 'Playing' ? 'Playing selections' : 'Hear my selections';
    listen.disabled = !current || !current.active || !current.builtins.length || !isSupported(current) || value === 'Loading' || value === 'Playing';
    pause.disabled = value !== 'Playing';
    stopButton.disabled = !['Loading', 'Playing', 'Paused'].includes(value);
  }
  function releaseSource() {
    if (source) { const old = source; source = null; old.onended = null; try { old.stop(); } catch (_) {} old.disconnect(); }
  }
  function stop(message) {
    revision++;
    releaseSource(); merged = null; offset = 0;
    paint(typeof message === 'string' ? message : 'Off');
  }
  function isSupported(s) {
    const m = manifest();
    return !!m && m.labelCount === 90 && m.bankUrl === BANK_URL && s.builtins.every(label => m.items[label] && !label.startsWith('@'));
  }
  function mount(s) {
    const named = document.getElementById(s.mode === 'checkin' ? 'el-checkin-named-display' : 'el-named-display');
    if (!named) return;
    if (!panel) {
      panel = document.createElement('section');
      panel.id = 'pp-selection-audio'; panel.className = 'pp-audio pp-selection-audio';
      panel.setAttribute('aria-label', 'Optional selected list word narration');
      panel.innerHTML = '<div class="pp-audio-top"><strong>Hear the list words you chose</strong><span class="pp-selection-state" role="status" aria-live="polite">Off</span></div><p class="pp-selection-transcript"></p><p class="pp-selection-notice"></p><div class="pp-audio-actions"><button type="button">Hear my selections</button><button type="button" disabled>Pause selections</button><button type="button" disabled>Stop selections</button></div><details><summary>Voice and privacy</summary><p>Provisional review audio using Kokoro af_heart. Pronunciation, naturalness and human listening review are pending. The complete generic word bank downloads when you first choose to listen. Your selected words are assembled in this page; your choices are not sent in audio requests. Your own writing stays unvoiced. No autoplay or browser voice fallback.</p></details>';
      stateNode = panel.querySelector('[role=status]');
      transcriptNode = panel.querySelector('.pp-selection-transcript');
      noticeNode = panel.querySelector('.pp-selection-notice');
      [listen, pause, stopButton] = panel.querySelectorAll('button');
      listen.onclick = play; pause.onclick = pausePlayback; stopButton.onclick = () => stop();
    }
    if (named.nextElementSibling !== panel) named.insertAdjacentElement('afterend', panel);
    panel.hidden = false;
  }
  function refresh() {
    let s;
    try { s = snapshot(); } catch (_) { stop('Selections unavailable. Read your words on screen.'); return; }
    const next = JSON.stringify(s);
    if (next === key) return;
    key = next; stop(); current = s;
    if (!s.active) { if (panel) panel.hidden = true; return; }
    mount(s);
    if (!panel) return;
    const words = s.builtins;
    const joined = words.length < 2 ? (words[0] || '') : words.length === 2 ? words.join(' and ') : words.slice(0, -1).join(', ') + ', and ' + words[words.length - 1];
    transcriptNode.textContent = words.length ? 'Audio transcript: You selected: ' + joined + '.' : 'There are no selected list words to read aloud.';
    noticeNode.textContent = s.customCount ? (words.length ? 'Your own words remain on screen and are not read aloud. This audio includes only the list words shown in the transcript.' : 'You used your own words. They remain on screen and are not read aloud.') : 'Optional. Reads only the list words shown in the transcript. You can stop at any time.';
    paint(isSupported(s) ? 'Off' : 'Word audio unavailable. Read your words on screen.');
  }
  async function loadBank() {
    if (!bankPromise) bankPromise = (async () => {
      const m = manifest();
      if (!m || m.bankUrl !== BANK_URL) throw Error('Bank unavailable');
      const response = await fetch(BANK_URL, { cache: 'force-cache', credentials: 'same-origin' });
      if (!response.ok || response.status !== 200 || response.headers.has('Content-Range')) throw Error('Complete bank required');
      const data = await response.arrayBuffer();
      if (data.byteLength !== m.bytes || !crypto.subtle) throw Error('Bank verification unavailable');
      const digest = [...new Uint8Array(await crypto.subtle.digest('SHA-256', data))].map(v => v.toString(16).padStart(2, '0')).join('');
      if (digest !== m.bankSha256) throw Error('Bank hash mismatch');
      const decoded = await context.decodeAudioData(data);
      if (decoded.numberOfChannels !== 1 || Math.abs(decoded.duration - m.totalFrames / m.sampleRate) > .002) throw Error('Bank decode mismatch');
      return decoded;
    })();
    return bankPromise;
  }
  function compose(decoded, s) {
    const m = manifest();
    const sequence = ['@intro'];
    s.builtins.forEach((label, index) => { if (index && index === s.builtins.length - 1) sequence.push('@and'); sequence.push(label); });
    const parts = sequence.map((label, index) => {
      const item = m.items[label];
      const start = Math.round(item.startFrame / m.sampleRate * decoded.sampleRate);
      const frames = Math.round(item.frames / m.sampleRate * decoded.sampleRate);
      const gap = index === 0 ? 0 : index === 1 ? .40 : label === '@and' ? .22 : sequence[index - 1] === '@and' ? .12 : .32;
      return { start, frames, gap: Math.round(gap * decoded.sampleRate) };
    });
    const frames = parts.reduce((n, p) => n + p.gap + p.frames, Math.round(.2 * decoded.sampleRate));
    const output = context.createBuffer(1, frames, decoded.sampleRate), samples = output.getChannelData(0), original = decoded.getChannelData(0);
    let cursor = 0;
    parts.forEach(p => { cursor += p.gap; samples.set(original.subarray(p.start, p.start + p.frames), cursor); cursor += p.frames; });
    return output;
  }
  async function play() {
    refresh();
    if (!current || !current.active || !current.builtins.length || !isSupported(current) || ['Loading', 'Playing'].includes(phase)) return;
    const resuming = phase === 'Paused' && merged;
    if (!resuming) stop();
    const token = ++revision, frozenKey = key, chosen = { ...current, builtins: current.builtins.slice() };
    if (window.PPPilot) window.PPPilot.stopAudio();
    window.dispatchEvent(new CustomEvent('pp-audio-intent', { detail: { source: 'selections' } }));
    paint('Loading');
    try {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) throw Error('Local audio unavailable');
      if (!context) context = new AudioContextClass({ sampleRate: 24000 });
      await context.resume();
      if (token !== revision || key !== frozenKey || document.hidden) return;
      if (!resuming) {
        const decoded = await loadBank();
        if (token !== revision || key !== frozenKey || document.hidden) return;
        merged = compose(decoded, chosen); offset = 0;
      }
      if (token !== revision || key !== frozenKey || document.hidden) return;
      const player = context.createBufferSource(); source = player;
      player.buffer = merged; player.connect(context.destination);
      player.onended = () => { if (source === player && token === revision) stop(); };
      startedAt = context.currentTime;
      player.start(0, offset); paint('Playing');
    } catch (_) { if (token === revision) stop('Word audio unavailable. Read your words on screen.'); }
  }
  function pausePlayback() {
    if (phase !== 'Playing' || !context || !merged) return;
    offset = Math.min(merged.duration, offset + Math.max(0, context.currentTime - startedAt));
    revision++; releaseSource(); paint('Paused');
  }
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { if (phase === 'Playing') pausePlayback(); else if (phase === 'Loading') stop(); }
  });
  window.addEventListener('pagehide', () => stop());
  window.addEventListener('hashchange', () => { stop(); refresh(); });
  window.addEventListener('popstate', () => { stop(); refresh(); });
  window.addEventListener('pp-audio-intent', event => { if (!event.detail || event.detail.source !== 'selections') stop(); });
  document.addEventListener('click', event => {
    if (panel && panel.contains(event.target)) return;
    const control = event.target.closest && event.target.closest('button,a,input');
    if (control) { stop(); queueMicrotask(refresh); }
  }, true);
  document.addEventListener('input', event => { if (event.target.closest('#emotion-labeling')) { stop(); queueMicrotask(refresh); } }, true);
  const root = document.getElementById('main-content') || document.body;
  new MutationObserver(refresh).observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ['class', 'style', 'hidden'] });
  window.PPSelectionAudio = Object.freeze({
    configure(options) { if (!options || typeof options.getSnapshot !== 'function') throw Error('A provenance snapshot provider is required'); provider = options.getSnapshot; key = ''; refresh(); },
    refresh,
    invalidate() { stop(); key = ''; refresh(); },
    stop,
    state: () => ({ phase, revision, bankRequested: !!bankPromise, active: !!current && current.active, selectedCount: current ? current.builtins.length : 0, customCount: current ? current.customCount : 0 })
  });
})();
