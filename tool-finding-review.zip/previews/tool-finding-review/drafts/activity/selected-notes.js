// Session-only, user-selected export. The preview and download use the same text.
export function printSelectedText(content,status){if(!content)return;let copy;
  try{
   copy=window.open('about:blank','_blank');
   if(!copy)throw new Error('Print window unavailable');
   copy.opener=null;
   const doc=copy.document,head=doc.createElement('head'),body=doc.createElement('body');
   const charset=doc.createElement('meta');charset.setAttribute('charset','utf-8');head.append(charset);
   const heading=doc.createElement('title');heading.textContent='Selected notes - print copy';head.append(heading);
   // Construct from the same selected-only string as the download. Never clone the source DOM.
   for(const line of content.split('\n')){const paragraph=doc.createElement('p');paragraph.textContent=line;body.append(paragraph);}
   doc.documentElement.lang='en';doc.documentElement.replaceChildren(head,body);
   copy.focus();copy.print();
   status.textContent='Print requested for a separate copy containing only your selection. Close that window when finished; clearing here does not close it.';
  }catch(error){if(copy&&!copy.closed)copy.close();status.textContent='Printing could not be safely prepared. Download selected notes instead.';}
 }

export function selectedNotes({title,entries,selected,filename}) {
 const make=(tag,text)=>{const node=document.createElement(tag);if(text!==undefined)node.textContent=text;return node;};
 const root=make('section');root.className='selected-notes';
 root.append(make('h3','Choose which notes to keep'),make('p','Nothing is selected automatically. Only selected, nonempty notes appear in the preview, downloaded file and separate print copy. Nothing is sent.'));
 const available=entries.filter(({value})=>value.trim());
 for(const id of [...selected])if(!available.some(entry=>entry.id===id))selected.delete(id);
 const fields=make('fieldset');fields.append(make('legend','Items to include'));
 const preview=make('pre');preview.className='preview selected-notes-preview';preview.style.whiteSpace='pre-wrap';preview.style.overflowWrap='anywhere';
 const download=make('button','Download selected notes');download.type='button';
 const print=make('button','Print selected notes / save as PDF');print.type='button';
 const status=make('p');status.setAttribute('role','status');
 const text=()=>{const chosen=available.filter(entry=>selected.has(entry.id));return chosen.length?title+'\n\n'+chosen.map(entry=>entry.label+'\n'+entry.value.trim()).join('\n\n')+'\n\nPersonal notes. No automatic sharing. A downloaded file remains where you save it.':'';};
 const update=()=>{preview.textContent=text()||'No items selected.';download.disabled=!text();print.disabled=!text();};
 for(const entry of available){const label=make('label');label.className='check';const input=make('input');input.type='checkbox';input.checked=selected.has(entry.id);input.addEventListener('change',()=>{input.checked?selected.add(entry.id):selected.delete(entry.id);update();});label.append(input,document.createTextNode(entry.label));fields.append(label);}
 download.addEventListener('click',()=>{const content=text();if(!content)return;const url=URL.createObjectURL(new Blob([content],{type:'text/plain;charset=utf-8'}));const anchor=make('a');anchor.href=url;anchor.download=filename;anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);status.textContent='Download requested. Check your file before clearing these notes.';});
 print.addEventListener('click',()=>printSelectedText(text(),status));

 root.append(fields,make('h3','Download preview'),preview,make('p','Saved copies may sync through your device settings. Close the separate print window when finished. Finishing clears notes here; it does not close that window or remove saved files.'),download,print,status);update();return root;
}
