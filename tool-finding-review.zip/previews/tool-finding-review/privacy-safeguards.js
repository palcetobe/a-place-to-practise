/* Local privacy controls. No usage analytics, network sender, or remote dependency. */
(function (global) {
  'use strict';
  var localKeys = ['mm_logs','mm_bottle_draft','mm_bottles','mm_bottle_last',
    'mm_bottle_bridge_dismissed_ts','mm_toolbox','mm_toolbox_intro_seen',
    'mm_reflection_shown','mm_checkins'];
  var sessionKeys = ['mm_visits','mm_last','mm_nq','mm_support_bar_dismissed',
    'mm_bottle_prefill','mm_ccg_route','mm_values_anchor','mm_values_context',
    'mm_urge_focus','mm_el_mode','mm_checkin_just_saved','mm_bottle_entry_context',
    'mm_from_library','mm_st_paths_open','mm_st_paths_chips','mm_sort_through_preserve',
    'mm_route_history_v1','mm_clear_notice'];
  var epochKey = 'mm_clear_epoch'; // Non-content reset version; invalidates stale tabs/BFCache.
  function readEpoch() { try { return localStorage.getItem(epochKey) || ''; } catch (_) { return ''; } }
  var initialEpoch = readEpoch();
  global._mmPrivacyClearing = false;

  // Stop old callbacks from writing while a clear/reload is in progress.
  ['saveLog','saveBottle','keepBottle','tbWrite','_elCheckinSaveEntry'].forEach(function (name) {
    var original = global[name];
    if (typeof original === 'function') global[name] = function () {
      if (global._mmPrivacyClearing) return false;
      return original.apply(this, arguments);
    };
  });
  function clearVisibleState() {
    if (global.NestedPrivacyRepairs) global.NestedPrivacyRepairs.clear();
    if (global.NativePersistenceLifecycle) global.NativePersistenceLifecycle.clear();
    // Clear in-frame memory even if saved-storage removal subsequently fails.
    if (global.ConsolidatedReview && typeof global.ConsolidatedReview.clearSession === 'function') global.ConsolidatedReview.clearSession();
    if (typeof global._stopActiveTimers === 'function') global._stopActiveTimers();
    document.querySelectorAll('input,textarea').forEach(function (el) {
      el.value = ''; if (el.type === 'checkbox' || el.type === 'radio') el.checked = false;
    });
    document.querySelectorAll('dialog[open]').forEach(function (el) { el.close(); });
    if (global.MMNavigation) global.MMNavigation.discardHistory();
  }
  function removeKeys(storage, keys) {
    keys.forEach(function (key) { storage.removeItem(key); });
    return keys.every(function (key) { return storage.getItem(key) === null; });
  }
  function reloadHome() {
    history.replaceState(null, '', location.pathname + '#page/home');
    // A full document reload discards exercise globals, generated outputs and timers.
    location.reload();
  }
  global.mmClearAppData = function () {
    global._mmPrivacyClearing = true;
    clearVisibleState();
    try {
      if (!removeKeys(localStorage, localKeys) || !removeKeys(sessionStorage, sessionKeys)) throw new Error('Incomplete removal');
      localStorage.setItem(epochKey, String(Date.now()));
      sessionStorage.setItem('mm_clear_notice', '1');
    } catch (_) {
      // Stored removal failed. Close the current exercise so hidden volatile
      // state cannot restore an apparently cleared answer or restart media.
      global._mmPrivacyClearing = true;
      try { sessionStorage.setItem('mm_clear_notice', 'failed'); } catch (_) {}
      alert("Some saved data could not be removed. Your open practice will close, but stored records may remain. Use your browser's site-data controls before sharing this device.");
      reloadHome();
      return false;
    }
    reloadHome();
    return true;
  };
  function invalidateStalePage() {
    if (readEpoch() === initialEpoch) return;
    global._mmPrivacyClearing = true;
    clearVisibleState();
    try { removeKeys(sessionStorage, sessionKeys); } catch (_) {}
    reloadHome();
  }
  global.addEventListener('storage', function (event) { if (event.key === epochKey) invalidateStalePage(); });
  global.addEventListener('pageshow', function (event) { if (event.persisted) invalidateStalePage(); });
  document.addEventListener('DOMContentLoaded', function () {
    ['clear-data-dialog','export-preview-dialog'].forEach(function (id) {
      document.getElementById(id).addEventListener('click', function (event) { event.stopPropagation(); });
    });
    try {
      if (sessionStorage.getItem('mm_clear_notice') === 'failed') {
        sessionStorage.removeItem('mm_clear_notice');
        var failedNotice = document.getElementById('triage-checkin-saved-ack');
        failedNotice.textContent = 'Some saved data could not be removed. Your open practice was closed. Stored records may remain; use browser site-data controls to clear them.';
        failedNotice.style.display = 'block'; failedNotice.setAttribute('role', 'alert');
      } else if (sessionStorage.getItem('mm_clear_notice') === '1') {
        sessionStorage.removeItem('mm_clear_notice');
        var notice = document.getElementById('triage-checkin-saved-ack');
        notice.textContent = 'Saved data cleared from this browser.';
        notice.style.display = 'block'; notice.setAttribute('role','status');
      }
    } catch (_) {}
    document.getElementById('export-preview-dialog').addEventListener('close', function () {
      document.getElementById('export-preview-text').value = ''; exportFilename = '';
      var trigger = exportTrigger; exportTrigger = null;
      if (trigger && trigger.isConnected && trigger.getClientRects().length) trigger.focus();
    });
    // Nested Settings handlers must not also handle a modal's Escape/Tab.
    document.addEventListener('keydown', function (event) {
      var preview = document.getElementById('export-preview-dialog');
      var clear = document.getElementById('clear-data-dialog');
      var modal = preview.open ? preview : clear.classList.contains('open') ? clear : null;
      if (!modal || (event.key !== 'Tab' && event.key !== 'Escape')) return;
      event.stopImmediatePropagation();
      if (event.key === 'Escape') {
        event.preventDefault();
        if (modal === preview) preview.close(); else global._mmBottleClearDialogCancel();
        return;
      }
      var fields = Array.from(modal.querySelectorAll('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])'))
        .filter(function (el) { return !el.disabled && el.getClientRects().length; });
      var first = fields[0], last = fields[fields.length - 1];
      if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }, true);
  });

  // Source instructions, captured before the person starts an exercise. PDF
  // extraction must not traverse live generated answers or acknowledgement text.
  var templates = {};
  document.querySelectorAll('.passage[id]').forEach(function (passage) { templates[passage.id] = passage.cloneNode(true); });
  global.mmPristineToolElement = function (entry) {
    var passage = templates[entry.p];
    if (!passage) return null;
    if (entry.c) {
      var nodes = passage.querySelectorAll('[id]');
      for (var i=0; i<nodes.length; i++) if (nodes[i].id === entry.c) return nodes[i];
    }
    return passage;
  };
  global.mmCurrentExerciseRoot = function () {
    var passage = document.getElementById(global._currentPage);
    var route = global.MMRoutes && global.MMRoutes.parse(location.hash).route;
    if (passage && route && route.passageId === passage.id && route.cardId) {
      var card = document.getElementById(route.cardId);
      if (card && passage.contains(card)) return card;
    }
    return passage;
  };
  global.mmCurrentExerciseFields = function () {
    var root = global.mmCurrentExerciseRoot();
    if (!root) return [];
    var fields = Array.from(root.querySelectorAll('textarea,input[type="text"]'));
    var route = global.MMRoutes && global.MMRoutes.parse(location.hash).route;
    // Several live forms are siblings of their instruction cards. Declare
    // ownership so an exact-card export retains its answers without sweeping
    // in answers from a different exercise on the same passage.
    var associated = {
      'card-distortions-thought-record-4-steps':['dist-thought','dist-reframe'],
      'card-hypoarousal-one-small-move-right-now':['hypo-move'],
      'card-wise-mind-how-to-access-it-right-now':['wm-answer'],
      'card-values-finding-yours-three-questions':['val-value'],
      'card-values-values-in-action':['val-value','val-action'],
      'card-inner-voices-name-the-voice':['iv-voice-text'],
      'card-inner-voices-question-it':['iv-voice-text','iv-response-text'],
      'card-inner-voices-narrator-swap':['iv-voice-text','iv-response-text'],
      'card-identity-reconstruction-prompts':['id-reconnect','id-survived','id-building','id-today'],
      'card-systemic-sort-whats-personal-vs-systemic':['sys-notmine','sys-agency']
    };
    if (route && associated[route.cardId]) {
      associated[route.cardId].forEach(function (id) {
        var field = document.getElementById(id); if (field && fields.indexOf(field) < 0) fields.push(field);
      });
    }
    return fields;
  };
  var exportFilename = '', exportTrigger = null;
  global.mmDismissPrivateDialogs = function () {
    exportTrigger = null; global._mmBottleClearDialogTrigger = null;
    var preview = document.getElementById('export-preview-dialog');
    if (preview && preview.open) preview.close();
    if (document.getElementById('export-preview-text')) document.getElementById('export-preview-text').value = '';
    exportFilename = '';
    if (document.getElementById('clear-data-dialog').classList.contains('open')) global._mmBottleClearDialogClose();
  };
  global.mmPreviewText = function (text, filename) {
    if (!document.getElementById('export-preview-dialog').open)
      exportTrigger = global._mmBottleClearDialogTrigger || document.activeElement;
    exportFilename = filename;
    document.getElementById('export-preview-text').value = text;
    document.getElementById('export-preview-dialog').showModal();
  };
  global.mmCloseExportPreview = function () { document.getElementById('export-preview-dialog').close(); };
  global.mmDownloadPreview = function () {
    var text = document.getElementById('export-preview-text').value, filename = exportFilename;
    if (!filename) return;
    var url = URL.createObjectURL(new Blob([text], {type:'text/plain;charset=utf-8'}));
    var link = document.createElement('a'); link.href = url; link.download = filename;
    document.body.appendChild(link); link.click(); link.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    global.mmCloseExportPreview();
  };
  global._mmUrgeSafetyAcknowledged = false;
  global.mmUrgeSafetyContinue = function () {
    global._mmUrgeSafetyAcknowledged = true;
    document.getElementById('us-safety-check').style.display = 'none';
    document.getElementById('us-practice-start').style.display = '';
    document.getElementById('us-urge-input').focus();
  };
  global.MMPrivacy = Object.freeze({localKeys:localKeys.slice(),sessionKeys:sessionKeys.slice()});
})(window);
