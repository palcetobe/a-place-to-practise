/* Create new native targets before the existing router validates a cold URL. */
(()=>{'use strict';const main=document.getElementById('main-content');if(!main)return;for(const[id,label,html]of[
["repair-attempt","Repair Attempt",'<div class="restored-native-body"></div>'],["ambivalent-grief-practice","Ambivalent Grief",'<div class="restored-native-body"></div>'],
['full-stop','STOP','<h2>STOP</h2><section class="stop-body"></section><p class="stop-status" role="status" aria-live="polite"></p>'],
['boundary-setting','Saying no to an everyday request','<div id="boundary-native-mount"></div><div id="boundary-native-ending" hidden></div><p id="boundary-native-status" role="status"></p>']
]){if(document.getElementById(id))continue;const root=document.createElement('div');root.id=id;root.className='passage';root.setAttribute('role','group');root.setAttribute('aria-label',label);root.innerHTML=html;(main.querySelector(':scope > .card')||main).append(root)}})();
