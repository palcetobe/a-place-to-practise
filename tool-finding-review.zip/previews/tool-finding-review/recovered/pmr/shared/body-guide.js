import {el} from './components.js';

// A proportioned, neutral outline: no gender, sex, hair, clothing or facial detail. Regions match m002 group IDs.
const regions = {
 lowerlegs:{view:'Back',paths:['M178 1065 L224 1065 L212 1270 L211 1352 L199 1395 L155 1398 L193 1350 L192 1230 Z','M296 1065 L342 1065 L328 1230 L327 1350 L365 1398 L321 1395 L309 1352 L308 1270 Z']},
 thighs:{view:'Front',paths:['M171 770 L242 789 L227 993 L181 993 Z','M278 789 L349 770 L339 993 L293 993 Z']},
 seat:{view:'Back',paths:['M172 661 Q259 641 348 661 L349 757 L171 757 Z']},
 back:{view:'Back',paths:['M189 522 L331 522 L333 603 Q260 619 187 603 Z']},
 abdomen:{view:'Front',paths:['M193 498 L327 498 L332 608 Q260 632 188 608 Z']},
 hands:{view:'Front',paths:['M56 731 L79 723 L86 754 L77 785 L65 765 L58 803 L49 783 Z','M441 723 L464 731 L471 783 L462 803 L455 765 L443 785 L434 754 Z']},
 arms:{view:'Front',paths:['M126 369 L158 389 L143 516 L110 509 Z','M362 389 L394 369 L410 509 L377 516 Z']},
 shoulders:{view:'Front',paths:['M203 312 L210 341 Q164 347 155 379 L128 365 Q143 325 203 312 Z','M317 312 Q377 325 392 365 L365 379 Q356 347 310 341 Z']},
 neck:{view:'Front',paths:['M241 246 L279 246 L282 282 L238 282 Z']},
 face:{view:'Front',zoom:true,paths:['M220 127 Q260 99 300 127 L302 181 Q260 194 218 181 Z']},
 jaw:{view:'Front',zoom:true,paths:['M217 188 Q260 208 303 188 L291 211 Q260 247 229 211 Z']}
};
const ns='http://www.w3.org/2000/svg';
function svgEl(tag,attrs={},...children){const n=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,v);n.append(...children);return n;}
const path=(d,cls)=>svgEl('path',{d,class:cls});
export function bodyGuide(group,phase){
 const r=regions[group.id];if(!r)return el('span');
 const message={prepare:'Find this area',tense:'A little gentle effort',rest:'Let the effort go',paused:'Rest here'}[phase];
 const svg=svgEl('svg',{viewBox:r.zoom?'155 75 215 295':'15 0 482 1460',role:'img','aria-label':`${group.name}, ${r.view.toLowerCase()} view. ${message}. Location guide, not a posture to copy.`,class:'body-map'});
 const outline=svgEl('g',{class:'body-outline'},
 svgEl('ellipse',{cx:260,cy:160,rx:59,ry:78}),
 path('M233 230 L233 280 Q219 300 181 309 Q139 315 122 343 Q105 373 101 419 L84 546 L60 676 L51 733 Q38 765 42 790 L53 819 Q60 830 66 819 L65 782 L74 754 L76 789 Q83 803 89 789 L95 750 Q98 733 91 715 L113 654 L145 549 L166 420 L177 528 Q179 568 168 617 Q152 687 159 759 L166 997 L179 1237 L179 1349 L153 1375 Q133 1398 153 1411 Q178 1420 212 1407 L223 1376 L224 1260 L236 1040 L253 791 Q260 771 267 791 L284 1040 L296 1260 L297 1376 L308 1407 Q342 1420 367 1411 Q387 1398 367 1375 L341 1349 L341 1237 L354 997 L361 759 Q368 687 352 617 Q341 568 343 528 L354 420 L375 549 L407 654 L429 715 Q422 733 425 750 L431 789 Q437 803 444 789 L446 754 L455 782 L454 819 Q460 830 467 819 L478 790 Q482 765 469 733 L460 676 L436 546 L419 419 Q415 373 398 343 Q381 315 339 309 Q301 300 287 280 L287 230','body-shape'));
 svg.append(outline);
 svg.append(svgEl('g',{'data-region':group.id,class:'body-region'},...r.paths.map(d=>path(d,'region-fill'))));
 return el('figure',{class:'body-guide','data-phase':phase,'data-area':group.id},el('div',{class:'body-map-wrap'},svg),el('figcaption',{},el('span',{class:'body-guide-view'},r.view+' view · '+(r.zoom?'Detail':'Area guide')),el('strong',{},group.name),el('span',{class:'body-guide-message'},message),el('small',{},'Area shown only. Keep your body supported.')));
}
