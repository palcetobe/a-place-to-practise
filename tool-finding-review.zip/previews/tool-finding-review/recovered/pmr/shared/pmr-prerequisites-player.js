/* Local prerequisite recording only. No autoplay, storage, sending or response collection. */
(()=>{
 const players=new Set();
 function attach(){document.querySelectorAll('audio[data-pmr-prerequisite-audio]').forEach(audio=>{
  if(audio.dataset.ready)return;audio.dataset.ready='true';players.add(audio);
  const sections=JSON.parse(audio.dataset.sections||'[]');let stopped=false;
  const state=document.createElement('p');state.setAttribute('data-prerequisite-player-status','');state.textContent='Recording ready. The complete transcript is below.';
  const controls=document.createElement('div');controls.className='actions pmr-prerequisite-controls';
  const replay=document.createElement('button');replay.type='button';replay.textContent='Replay prerequisites';
  const stop=document.createElement('button');stop.type='button';stop.textContent='Stop prerequisites';
  const fail=()=>{state.textContent='Recording unavailable. Use the written transcript or review it with suitable support before physical practice.';};
  function current(){if(stopped){state.textContent='Stopped. The transcript remains below.';return;}const s=sections.find(x=>audio.currentTime>=x.start&&audio.currentTime<x.end)||sections.filter(x=>x.start<=audio.currentTime).at(-1);state.textContent=(audio.paused?'Paused: ':'Listening: ')+(s?.heading||'prerequisite guidance')+'. The transcript remains below.';}
  audio.addEventListener('timeupdate',current);audio.addEventListener('play',()=>{stopped=false;for(const other of players)if(other!==audio)other.pause();current();});
  audio.addEventListener('pause',current);audio.addEventListener('ended',()=>{state.textContent='Recording ended. You can replay it or review the transcript. Playback does not establish understanding or movement suitability.';});audio.addEventListener('error',fail);
  replay.addEventListener('click',()=>{stopped=false;audio.currentTime=0;audio.play().catch(fail);});
  stop.addEventListener('click',()=>{stopped=true;audio.pause();audio.currentTime=0;current();});
  controls.append(replay,stop);audio.after(controls,state);
 });for(const a of players)if(!a.isConnected){a.pause();players.delete(a);}}
 new MutationObserver(attach).observe(document.documentElement,{childList:true,subtree:true});
 document.addEventListener('visibilitychange',()=>{if(document.hidden)for(const a of players)a.pause();});
 addEventListener('pagehide',()=>{for(const a of players)a.pause();});
 attach();
})();
