// Keep resource failures usable instead of leaving an empty exercise.
import('./app.js').then(()=>{document.getElementById('clear').disabled=false;}).catch(()=>{
 const root=document.getElementById('main');root.replaceChildren();root.dataset.view='load-error';
 const title=document.createElement('h1');title.textContent='The exercise could not load.';title.tabIndex=-1;
 const message=document.createElement('p');message.textContent='Please try loading it again. You can still download the PMR quick guide below.';
 const retry=document.createElement('button');retry.className='primary';retry.textContent='Try loading again';retry.onclick=()=>location.reload();
 root.append(title,message,retry);title.focus();
});
