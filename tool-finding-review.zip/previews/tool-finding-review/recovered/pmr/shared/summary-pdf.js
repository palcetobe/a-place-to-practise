import {fontBytes} from './pdf-font.js';
// Browser memory only. Neither this function nor the caller sends responses anywhere.
export async function buildSummary(sections,mode){
 const {PDFDocument,rgb}=globalThis.PDFLib;
 const pdf=await PDFDocument.create();pdf.registerFontkit(globalThis.fontkit);
 const font=await pdf.embedFont(fontBytes,{subset:true});
 const ink=rgb(.137,.282,.243),muted=rgb(.345,.400,.373),line=rgb(.70,.76,.72);
 pdf.setTitle('My muscle relaxation practice');pdf.setAuthor('Practice Room');
 let page,y;const pages=[];const supported=new Set(font.getCharacterSet());
 // Do not silently substitute missing glyphs: the caller leaves the entries intact.
 for(const {value} of sections)for(const ch of value){if(!'\n\r\t'.includes(ch)&&!supported.has(ch.codePointAt(0)))throw Error('Unsupported character');}
 const draw=(t,x,y,size=11,color=ink)=>page.drawText(t,{x,y,size,font,color});
 function addPage(){page=pdf.addPage([612,792]);pages.push(page);y=684;draw('PRACTICE ROOM  /  PERSONAL TAKEAWAY',48,748,9,muted);draw('My practice summary',48,711,23);}
 function wrap(text,size=11,width=516){const lines=[];for(const paragraph of text.replace(/\r\n?/g,'\n').split('\n')){let current='';for(const word of paragraph.split(/\s+/)){const candidate=current?current+' '+word:word;if(font.widthOfTextAtSize(candidate,size)<=width){current=candidate;continue;}if(current){lines.push(current);current='';}for(const char of word){if(font.widthOfTextAtSize(current+char,size)>width){lines.push(current);current='';}current+=char;}}lines.push(current);}return lines;}
 function paragraph(text,size=11,color=ink){for(const t of wrap(text,size)){if(y<86)addPage();draw(t,48,y,size,color);y-=17;}y-=8;}
 addPage();paragraph(mode==='observe'?'Read-through: no physical practice recorded.':'Guided muscle relaxation practice.',10,muted);paragraph('A record you chose to keep. Nothing has been sent to your therapist. This is not a clinical assessment.',10,muted);
 for(const {title,value} of sections){if(y<140)addPage();y-=8;draw(title,48,y,14);y-=23;paragraph(value);}
 if(y<165)addPage();y-=10;draw('For another practice',48,y,14);y-=24;
 paragraph('Use gentle effort, keep breathing, release and rest. Skip unsuitable movements. Stop for discomfort and discuss fit before trying that movement again. No particular feeling or score is required.',10);
 paragraph('The PMR quick guide is a separate download in the exercise. Keep or share this summary only if you choose. Clearing the exercise does not remove downloaded files.',9,muted);
 pages.forEach((p,i)=>{p.drawLine({start:{x:48,y:58},end:{x:564,y:58},thickness:1,color:line});p.drawText('Private copy  |  m002 v0.2.0-review',{x:48,y:39,size:8,font,color:muted});p.drawText(`${i+1} / ${pages.length}`,{x:530,y:39,size:8,font,color:muted});});
 return pdf.save();
}



