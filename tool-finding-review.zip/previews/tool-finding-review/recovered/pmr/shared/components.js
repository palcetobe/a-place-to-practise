export function el(tag,attrs={},...children){const n=document.createElement(tag);for(const[k,v]of Object.entries(attrs)){if(k.startsWith('on'))n.addEventListener(k.slice(2),v);else if(k==='class')n.className=v;else n.setAttribute(k,v);}for(const c of children.flat())if(c!==undefined&&c!==null)n.append(c instanceof Node?c:document.createTextNode(String(c)));return n;}
export const button=(text,fn,primary=false)=>el('button',{onclick:fn,class:primary?'primary':''},text);
export const p=t=>el('p',{},t);
export const note=t=>el('aside',{},t);
export function selectField(label,options,value,change){const s=el('select',{'aria-label':label},options.map(([v,t])=>el('option',{value:v},t)));s.value=value||'';s.onchange=()=>change(s.value);return el('label',{class:'field'},el('span',{},label),s);}
export function textField(label,value,change,max=700){const t=el('textarea',{'aria-label':label,maxlength:max,rows:4,autocomplete:'off',spellcheck:'false'});t.value=value||'';t.oninput=()=>change(t.value);return el('label',{class:'field'},el('span',{},label),t);}
export function download(bytes,type,name){const u=URL.createObjectURL(new Blob([bytes],{type}));const a=el('a',{href:u,download:name});document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),1000);}
