const $=s=>document.querySelector(s);
document.querySelectorAll('button').forEach(b=>b.disabled=true);
const stages=await (await fetch('script.json')).json();
const voices=stages.map((_,i)=>new Audio(`assets/heart-${i}.wav`));
const durations=await Promise.all(voices.map(a=>new Promise(resolve=>{const timer=setTimeout(()=>resolve(9),4000);function done(value){clearTimeout(timer);resolve(value);}a.addEventListener('loadedmetadata',()=>done(Number.isFinite(a.duration)?a.duration+0.7:9),{once:true});a.addEventListener('error',()=>done(9),{once:true});a.load();})));
const total=durations.reduce((a,b)=>a+b,0);
let index=0,elapsed=0,running=false,finished=false,last=0;
const progress=$('.progress'),play=$('#play'),sound=$('#sound');
$('#motion').checked=matchMedia('(prefers-reduced-motion: reduce)').matches;
function motion(){document.body.classList.toggle('reduced',$('#motion').checked);}motion();$('#motion').onchange=motion;
stages.forEach(s=>{const li=document.createElement('li');li.textContent=s.text;$('#transcript').append(li);});
function paint(){const s=stages[index];$('#art').classList.toggle('tense',s.pose==='tense');$('#art').setAttribute('aria-label',s.pose==='tense'?'The same supported hand with fingers curled into a gentle fist':'A supported hand resting loosely on a cushion');$('#phase').textContent=`0${index+1} · ${s.label}`;$('#heading').textContent=s.title;$('#caption').textContent=s.text;$('#kicker').textContent=`ONE CYCLE / ${index+1} OF ${stages.length}`;document.querySelectorAll('.steps span').forEach((e,i)=>e.classList.toggle('active',i===index));}
function progressPaint(){const value=finished?100:(durations.slice(0,index).reduce((a,b)=>a+b,0)+elapsed)/total*100;$('#fill').style.width=`${Math.min(value,100)}%`;progress.setAttribute('aria-valuenow',String(Math.round(value)));}
function stopAudio(){voices.forEach(a=>a.pause());}
function startAudio(){const a=voices[index];a.muted=!sound.checked;if(elapsed<a.duration){a.currentTime=elapsed;a.play().catch(()=>{$('#status').textContent='Narration unavailable. The captions contain the full explanation.';});}}
function pause(message='Paused. If you were following along, let your hand rest.'){running=false;stopAudio();play.textContent='Resume';$('#status').textContent=message;$('#art').classList.remove('tense');$('#art').setAttribute('aria-label','The hand at rest while the explanation is paused');$('#phase').textContent='Paused · Rest';$('#heading').textContent='Let your hand rest.';$('#caption').textContent='The explanation is paused. There is no need to keep any muscles tense.';}
function finish(){running=false;finished=true;stopAudio();index=3;elapsed=durations[3];paint();progressPaint();play.textContent='Play again';$('#status').textContent='Sample finished. This is one example, not the full PMR exercise.';}
function start(reset=false){stopAudio();if(reset||finished){index=0;elapsed=0;finished=false;}running=true;paint();startAudio();play.textContent='Pause';$('#status').textContent='Watching the explanation. You do not need to follow along.';if(innerWidth<=700)document.querySelector('.player').scrollIntoView({block:'start',behavior:'instant'});last=performance.now();}
play.onclick=()=>running?pause():start();$('#replay').onclick=()=>start(true);$('#skip').onclick=finish;
sound.onchange=()=>voices.forEach(a=>a.muted=!sound.checked);
document.addEventListener('visibilitychange',()=>{if(document.hidden&&running)pause();});window.addEventListener('pagehide',()=>{running=false;stopAudio();});
function tick(now){if(running){const a=voices[index];if(!a.paused&&!a.ended){elapsed=a.currentTime;}else elapsed+=(now-last)/1000;if(elapsed>=durations[index]){if(index===3)finish();else{index++;elapsed=0;stopAudio();paint();startAudio();}}progressPaint();}last=now;requestAnimationFrame(tick);}requestAnimationFrame(tick);
document.querySelectorAll('button').forEach(b=>b.disabled=false);

window.PMRDemo=Object.freeze({pause(){if(running)pause();else stopAudio();},stop(){running=false;stopAudio();},state:()=>({running,index,playing:voices.some(a=>!a.paused)})});
