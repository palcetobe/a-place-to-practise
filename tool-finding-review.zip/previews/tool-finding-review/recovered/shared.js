const M={};M['attention-reader.js']={createAuthoredReader:()=>({mark:n=>n,mount:()=>document.createDocumentFragment(),stop(){},dispose(){}})};
M["landing-choices.js"]=(function(){
// Shared PMR-style landing choices. Callbacks keep each skill's existing teaching and practice flow.
function landingChoices({el,button,learn,practice,context=[],more=[]}) {
 const choices=el('section',{class:'skill-landing-choices','aria-label':'Choose how to begin'},
  el('div',{class:'actions skill-landing-actions'},
   button('Learn the skill',learn,true),button('Practise the skill',practice)));
 if(more.length)choices.append(el('details',{class:'skill-landing-more'},
  el('summary',{},'Other ways to use this exercise'),...context,el('div',{class:'actions'},...more)));
 return choices;
}

return {landingChoices};})();
M["selected-notes.js"]=(function(){
// Session-only, user-selected export. The preview and download use the same text.
function printSelectedText(content,status){if(!content)return;let copy;
  try{
   copy=window.open('about:blank','_blank');
   if(!copy)throw new Error('Print window unavailable');
   copy.opener=null;
   const doc=copy.document,head=doc.createElement('head'),body=doc.createElement('body');
   const charset=doc.createElement('meta');charset.setAttribute('charset','utf-8');head.append(charset);
   const heading=doc.createElement('title');heading.textContent='Selected notes - print copy';head.append(heading);
   // Construct from the same selected-only string as the download. Never clone the source DOM.
   for(const line of content.split('\n')){const paragraph=doc.createElement('p');paragraph.textContent=line;body.append(paragraph);}
   doc.documentElement.lang='en';doc.documentElement.replaceChildren(head,body);
   copy.focus();copy.print();
   status.textContent='Print requested for a separate copy containing only your selection. Close that window when finished; clearing here does not close it.';
  }catch(error){if(copy&&!copy.closed)copy.close();status.textContent='Printing could not be safely prepared. Download selected notes instead.';}
 }

function selectedNotes({title,entries,selected,filename}) {
 const make=(tag,text)=>{const node=document.createElement(tag);if(text!==undefined)node.textContent=text;return node;};
 const root=make('section');root.className='selected-notes';
 root.append(make('h3','Choose which notes to keep'),make('p','Nothing is selected automatically. Only selected, nonempty notes appear in the preview, downloaded file and separate print copy. Nothing is sent.'));
 const available=entries.filter(({value})=>value.trim());
 for(const id of [...selected])if(!available.some(entry=>entry.id===id))selected.delete(id);
 const fields=make('fieldset');fields.append(make('legend','Items to include'));
 const preview=make('pre');preview.className='preview selected-notes-preview';preview.style.whiteSpace='pre-wrap';preview.style.overflowWrap='anywhere';
 const download=make('button','Download selected notes');download.type='button';
 const print=make('button','Print selected notes / save as PDF');print.type='button';
 const status=make('p');status.setAttribute('role','status');
 const text=()=>{const chosen=available.filter(entry=>selected.has(entry.id));return chosen.length?title+'\n\n'+chosen.map(entry=>entry.label+'\n'+entry.value.trim()).join('\n\n')+'\n\nPersonal notes. No automatic sharing. A downloaded file remains where you save it.':'';};
 const update=()=>{preview.textContent=text()||'No items selected.';download.disabled=!text();print.disabled=!text();};
 for(const entry of available){const label=make('label');label.className='check';const input=make('input');input.type='checkbox';input.checked=selected.has(entry.id);input.addEventListener('change',()=>{input.checked?selected.add(entry.id):selected.delete(entry.id);update();});label.append(input,document.createTextNode(entry.label));fields.append(label);}
 download.addEventListener('click',()=>{const content=text();if(!content)return;const url=URL.createObjectURL(new Blob([content],{type:'text/plain;charset=utf-8'}));const anchor=make('a');anchor.href=url;anchor.download=filename;anchor.click();setTimeout(()=>URL.revokeObjectURL(url),1000);status.textContent='Download requested. Check your file before clearing these notes.';});
 print.addEventListener('click',()=>printSelectedText(text(),status));

 root.append(fields,make('h3','Download preview'),preview,make('p','Saved copies may sync through your device settings. Close the separate print window when finished. Finishing clears notes here; it does not close that window or remove saved files.'),download,print,status);update();return root;
}

return {printSelectedText,selectedNotes};})();
M["attention-return-flow.js"]=(function(){const {createAuthoredReader}=M["attention-reader.js"];
const {landingChoices}=M["landing-choices.js"];
const {selectedNotes}=M["selected-notes.js"];



// Shared interaction structure for bounded practice-planning support.
// Each skill supplies its own clinical target, examples, transfer and feedback.
function renderAttentionFlow({main,el,p,button},c){
 const reader=createAuthoredReader();
 const ap=text=>reader.mark(p(text),text);

 if(!document.querySelector('link[href="practice-support.css"]'))document.head.append(el('link',{rel:'stylesheet',href:'practice-support.css'}));
 if(!document.querySelector('link[href="attention-reader.css"]'))document.head.append(el('link',{rel:'stylesheet',href:'attention-reader.css'}));
 if(!document.querySelector('link[href="attention-return.css"]'))document.head.append(el('link',{rel:'stylesheet',href:'attention-return.css'}));
 const life=new AbortController(),kept=new Set();let view=location.hash.startsWith('#play/')?'example':'intro',first=null,second=null,help=null,kind='fresh',mode='write',reviewed=false;const notes=c.fields.map(()=> '');
 let point=null,readNotice=false;
 const clear=()=>{notes.fill('');kept.clear();point=null;readNotice=false;first=second=help=null;kind='fresh';mode='write';reviewed=false;};const dispose=()=>{clear();reader.dispose();life.abort();};addEventListener('hashchange',dispose,{signal:life.signal});addEventListener('pagehide',dispose,{signal:life.signal});
 const actions=(...nodes)=>el('div',{class:'actions'},...nodes),h=text=>reader.mark(el('h2',{tabindex:'-1'},text),text),detail=(name,...nodes)=>el('details',{},el('summary',{},name),...nodes);
 const link=(text,href)=>el('a',{class:'button',href,target:href.startsWith('#')?'_self':'_blank',rel:'noopener'},text);
 const quote=(who,text)=>el('blockquote',{class:'support-message'},el('span',{class:'eyebrow'},who),ap(text));
 const art=()=>el('figure',{class:'support-art'},el('img',{src:c.image,width:1536,height:1024,alt:c.alt}),el('figcaption',{},c.caption));
 function go(next){view=next;draw();(view==='intro'?main.querySelector('h1'):main.querySelector('h2[tabindex]'))?.focus({preventScroll:true});scrollTo(0,0);}
 const home=document.querySelector('#exercise-home'),finish=document.querySelector('#exercise-finish');if(home){home.setAttribute('aria-label','Practice Room - return to introduction; keep current notes');home.onclick=e=>{e.preventDefault();go('intro');};}if(finish)finish.onclick=()=>{clear();go('finished');};
 function picks(items,current,fn){return el('div',{class:'support-options'},...items.map((t,i)=>el('button',{type:'button','aria-pressed':String(current===i),onclick:()=>{fn(i);draw();main.querySelector('.support-feedback')?.focus();}},t)));}
 function feedback(data,i){return el('section',{class:'support-feedback',role:'status',tabindex:'-1'},el('h3',{},data[i].heading),ap(data[i].text));}
 function progress(){const phase=view==='lesson'?0:['example','adapt'].includes(view)?1:['practice','switch','mode'].includes(view)?2:3;return el('ol',{class:'pmr-journey','aria-label':'Exercise sections'},...['Learn','Try an example','Your rehearsal','Take away'].map((t,n)=>el('li',n===phase?{'aria-current':'step'}:{},el('span',{},String(n+1).padStart(2,'0')),t)));}
 function field(f,i){return el('div',{class:'support-field'},reader.mark(el('label',{for:'support-note-'+i},f.label),f.label),el('p',{class:'meta',id:'support-hint-'+i},f.hint),...(mode==='write'?[el('textarea',{id:'support-note-'+i,rows:3,maxlength:1200,autocomplete:'off','aria-describedby':'support-hint-'+i,oninput:e=>{notes[i]=e.target.value;reviewed=false;help=null;}},notes[i])]:[ap('Think, talk, sign or use another communication method. Nothing is recorded.')]));}

 function readingTask(){const lines=['Lee placed a blue pot beside the garden bench.','The gate opened onto a quiet path.','A small wooden sign pointed toward the herb beds.'];
 return el('section',{class:'support-context attention-reading'},el('h3',{},'Optional: try a brief reading task'),ap('Read these lines, listen with support or use them for a spoken rehearsal. If attention moves, notice that and choose where to return. If it does not move, you can choose a starting point without creating a distraction. Nothing is timed or measured.'),...lines.map((t,i)=>el('p',{'data-line':String(i),...(point===i?{class:'attention-current'}:{})},t)),actions(button('I noticed attention elsewhere',()=>{readNotice=true;draw();main.querySelector('.attention-cue')?.focus();})),...(readNotice?[el('p',{class:'attention-cue',role:'status',tabindex:'-1'},'You can choose a sentence below and read from it, or pause. Thoughts can remain; noticing does not need a score.')]:[]),ap('Choose a starting point, then actually read or listen from those words. Each point can fit; the tool cannot observe where your attention is.'),...lines.map((t,i)=>el('button',{type:'button','aria-pressed':String(point===i),onclick:()=>{point=i;draw();main.querySelector('.attention-return-cue')?.focus();}},'Start from: '+t.split(' ').slice(0,3).join(' '))),...(point!==null?[el('p',{class:'attention-return-cue',role:'status',tabindex:'-1'},'Your chosen point is marked. Read or listen from “'+lines[point].split(' ').slice(0,3).join(' ')+'”. Change your choice, pause or stop whenever that fits.')]:[]),ap('No written answer is needed. The optional notes below can help you review what you chose.'));
 }

 
 function demonstration(){return el('section',{class:'attention-demo'},h('See Sky choose a return'),ap('Sky chose to read this short library notice. While looking at the page, Sky notices planning tomorrow’s shopping.'),el('div',{class:'attention-demo-notice'},reader.mark(el('h3',{},'Saturday library hours'),'Saturday library hours'),ap('The library opens at ten.'),ap('Please return books at the desk.')),detail('An imperfect attempt and a small adjustment',ap('Sky looks at the page and tells himself to concentrate harder. He has not yet chosen where to begin.'),ap('He chooses the opening-times sentence and reads from those words. He does not wait for the planning thought to disappear.')),ap('Chosen return point:'),el('div',{class:'attention-demo-selected'},ap('The library opens at ten.')),ap('Sky reads from that sentence. The underline, left border and label identify his chosen text; they do not measure his attention.'),ap('A housemate then asks a practical question. Sky can answer, then choose whether to return to the marked sentence, change activity or pause.'));}
 function bridge(){return el('section',{class:'attention-bridge'},h('A small way to use this later'),ap('If it fits your therapy, choose an ordinary situation and one specific part of the task to return to. For example, during a routine message, choose its next sentence.'),ap('Choose a manageable opportunity that suits you. If continuing does not fit, change the task or format, ask for support or pause. No set number of tries or improvement is required.'),ap('Agree when and how to review this with your therapist. Bring whether you tried it, the choice you made, any obstacle or change, and anything unhelpful or unchanged. Thinking or talking is enough; this page does not schedule or send anything.'));}

 const situationCopy=key=>kind==='own'&&c.ownCopy?.[key]!==undefined?c.ownCopy[key]:c[key];
 function draw(){reader.stop();main.replaceChildren();const root=el('div',{class:'values-module support-module','data-view':view,'data-skill':c.id});main.append(root);reader.mount(root);root.append(el('p',{class:'eyebrow'},'Teaching review / '+c.tag));
 if(view==='intro'){
 root.append(el('div',{class:'values-hero'},el('section',{},el('h1',{class:'pmr-hero-title',tabindex:'-1'},c.hero[0],el('em',{},c.hero[1])),ap(c.lead),el('p',{class:'meta'},'About 5–10 minutes · Read, think, talk or write'),landingChoices({el,button,learn:()=>go('lesson'),practice:()=>go('example')})),art()),el('section',{class:'values-intro-note'},h(c.introHeading),ap(c.intro),ap(c.boundary),detail('Privacy and optional materials',ap('Choices and notes stay in this page’s memory. Returning here keeps notes; finishing, refreshing or leaving clears them. Downloaded copies remain where you save them and may sync through your device settings.'),actions(link('Readable teaching handout',c.id+'-readable-handout.html'),link('Teaching card (PDF)',c.id+'-teaching-card.pdf'),link('Teaching card and optional worksheet (PDF)',c.id+'-teaching-and-practice.pdf'))),...(notes.some(Boolean)?[ap('Your current rehearsal notes are still available.'),actions(button('Return to my rehearsal',()=>go('practice')))]:[])));return;}
 root.append(el('h1',{},c.title),progress());const b=el('section',{class:'activity-board values-board support-board'});root.append(b);
 if(view==='lesson'){
 b.append(h(c.lessonHeading),el('ol',{class:'support-lesson'},...c.lesson.map(x=>el('li',{},reader.mark(el('strong',{},x.heading),x.heading),ap(x.text)))),demonstration(),ap(c.lessonLimit),detail('Planned demonstration — storyboard, not a finished video',ap('The written teaching and examples are complete. The storyboard and script describe a possible future video; no finished video or audio is available.'),actions(link('Read the storyboard and script',c.id+'-storyboard.html'))),actions(button(c.beginExample,()=>go('example'),true),button('Try a fresh rehearsal',()=>go('practice')),button('Finish without practising',()=>go('review'))));
 }else if(view==='example'){
 b.append(h(c.exampleHeading),el('div',{class:'support-example'},art(),el('div',{},ap(c.exampleContext))),ap(c.exampleTask),picks(c.firstOptions,first,i=>first=i));if(first!==null)b.append(feedback(c.firstFeedback,first));b.append(actions(button(first===null?'Read a possible approach and what changes':c.nextStage,()=>go('adapt'),true),button('Try a fresh rehearsal',()=>go('practice')),button('Finish with this example',()=>go('review'))));
 }else if(view==='adapt'){
 b.append(h(c.adaptHeading),quote('The starting point',c.exampleModel),ap(c.changedContext),ap(c.adaptTask),picks(c.secondOptions,second,i=>second=i));if(second!==null)b.append(feedback(c.secondFeedback,second));b.append(detail('Read one possible continuation',ap(c.continuation)),actions(button('Try a fresh rehearsal before seeing a model',()=>go('practice'),true),button('Revisit the first choices',()=>go('example')),button('Finish with this example',()=>go('review'))));
 }else if(view==='switch'){
 b.append(h(kind==='fresh'?'Use your own situation?':'Return to the fictional rehearsal?'),ap('Changing the situation clears your current notes and download selections. Go back to review or download them first if you want to keep them.'),actions(button('Clear notes and change the situation',()=>{notes.fill('');kept.clear();point=null;readNotice=false;help=null;reviewed=false;kind=kind==='fresh'?'own':'fresh';go('practice');},true),button('Keep my current rehearsal',()=>go('practice'))));
 }else if(view==='mode'){
 b.append(h('Change how you rehearse?'),ap('Switching to thinking or talking clears written notes and download selections. You can go back to review or download them first.'),actions(button('Clear written notes and think or talk',()=>{notes.fill('');kept.clear();point=null;readNotice=false;help=null;mode='spoken';go('practice');},true),button('Keep writing',()=>go('practice'))));
 }else if(view==='practice'){
 b.append(h(kind==='fresh'?c.freshHeading:c.ownHeading),...(kind==='fresh'?[el('section',{class:'support-context'},el('h3',{},'A different fictional situation'),ap(c.freshContext))]:[ap(c.ownContext)]),ap(situationCopy('practiceTask')),...(kind==='fresh'?[readingTask()]:[]),...c.fields.map(field),detail('Help with the method',ap(situationCopy('processHelp'))),actions(button('Review my rehearsal',()=>{reviewed=true;go('review');},true),button(kind==='fresh'?'Use my own situation':'Use the fictional situation',()=>go('switch')),button(mode==='write'?'Change to thinking or talking':'Use optional writing boxes',()=>{if(mode==='write')go('mode');else{mode='write';go('practice');}}),button('Revisit the example',()=>go('example')),button('Finish without adding an answer',()=>{reviewed=true;go('review');})));
 }else if(view==='review'){
 b.append(h(c.reviewHeading),ap(c.takeaway),...(notes.some(Boolean)?[el('section',{class:'support-recap','data-private':'rehearsal-notes'},el('h3',{},'Your optional rehearsal notes'),...c.fields.map((f,i)=>el('div',{},el('strong',{},f.label),p(notes[i]||'Left open.'))))]:[ap('No written response is needed. You can keep the method, return to rehearse or leave it here.')]),...(reviewed?[el('section',{class:'support-context'},el('h3',{},'Review the rehearsal yourself'),el('ul',{},...situationCopy('reviewChecks').map(t=>reader.mark(el('li',{},t),t))),ap('These prompts do not assess your words. You can revise any part, choose support or decide not to continue.')),el('h3',{},'If one part needs attention'),ap('Choose an area for a process suggestion. This does not analyse your notes.'),picks(situationCopy('reviewHelp').map(x=>x.heading),help,i=>help=i)]:[]));if(reviewed&&help!==null)b.append(feedback(situationCopy('reviewHelp'),help));
 if(reviewed)b.append(detail(kind==='fresh'?'Compare with one possible rehearsal':"Optional fictional comparison: Lee's garden note",el('ol',{},...c.freshModel.map(t=>reader.mark(el('li',{},t),t))),ap(c.modelLimit)));
 if(mode==='write'&&notes.some(s=>s.trim())){const exportBlock=selectedNotes({title:c.title+' — my rehearsal',entries:c.fields.map((f,id)=>({id,label:f.label,value:notes[id]})),selected:kept,filename:c.id+'-my-rehearsal.txt'});exportBlock.setAttribute('data-private','export-preview');b.append(exportBlock); }
 b.append(bridge());
  b.append(actions(button('Return to my rehearsal',()=>go('practice')),button('Return to introduction; keep notes',()=>go('intro')),button('Finish and clear this exercise',()=>{clear();go('finished');},true),link('Teaching card (PDF)',c.id+'-teaching-card.pdf'),link('Optional worksheet (PDF)',c.id+'-teaching-and-practice.pdf')));
 }else if(view==='finished'){
 b.append(h('You can leave it here'),ap('Your choices and on-page notes have been cleared. Downloaded or printed copies remain where you saved them.'),ap(c.finish),actions(button('Return to the introduction',()=>go('intro'),true),link('Return to therapist library','#library')));
 }
 }
 draw();
}

return {renderAttentionFlow};})();
M["attention-return.js"]=(function(){const {renderAttentionFlow}=M["attention-return-flow.js"];

const config={
  "id": "attention-return",
  "title": "Returning attention to a chosen task",
  "hero": [
    "Returning attention",
    " to a chosen task"
  ],
  "tag": "Flexible attention return",
  "image": "media/practice-plan/sky.png",
  "alt": "An adult at a quiet table holding a small card beside an open notebook.",
  "caption": "Sky chooses a point to read. Illustration reused from A realistic practice plan.",
  "lead": "Notice when attention has moved elsewhere, choose whether to continue, and return to something specific in the task. You do not need an empty mind or uninterrupted concentration.",
  "introHeading": "A return can be a small action",
  "intro": "For therapist-supported adults using an ordinary, safe task of their choice. Help Sky return to reading, then try a short reading task or rehearse with your own suitable activity. Read, listen with support, think, talk or write; skip or stop at any point.",
  "boundary": "This is not a concentration test or treatment for attention difficulties. Use a safe, low-stakes task. Do not practise while driving, using machinery or doing anything that needs continuous safety attention. If focusing makes you more distressed, disconnected or uncomfortable, stop and discuss an alternative with your therapist.",
  "lessonHeading": "Notice, choose, return",
  "lesson": [
    {
      "heading": "Notice where attention has gone.",
      "text": "You might notice a thought, planning, a noise or losing your place. Noticing is enough; you do not need to judge yourself, analyse the distraction or make it disappear."
    },
    {
      "heading": "Choose what deserves attention now.",
      "text": "Check whether you want and are able to continue. An important interruption may need a response; fatigue, access needs or discomfort may call for a change or a pause."
    },
    {
      "heading": "Return to a specific part of the task.",
      "text": "If continuing fits, choose something concrete: the next words on a page or the next part of an ordinary activity. Begin there. Attention may move again; you can notice and choose again without counting returns."
    }
  ],
  "exampleModel": "Sky notices planning tomorrow while reading a short library notice. Sky chooses the sentence about opening times and reads from those words, without waiting for the planning thought to vanish.",
  "lessonLimit": "The target is a chosen return, not staying focused for a set time, finishing the task or feeling calm. This original brief adaptation does not provide a full attention-training, meditation, worry-postponement or grounding programme.",
  "beginExample": "Help Sky choose a return",
  "exampleHeading": "What would a return look like?",
  "exampleContext": "Sky chose to read a short library notice at a quiet table. Halfway through, Sky notices thinking about tomorrow\u2019s shopping instead of the notice. Nothing urgent needs attention, and Sky wants to continue reading.",
  "exampleTask": "Choose a response. Look for an observable return to the chosen task rather than a demand to remove thoughts.",
  "firstOptions": [
    "Wait until every shopping thought is gone before reading.",
    "Choose the sentence about opening times and read from those words.",
    "Start the whole notice again as a penalty for losing focus."
  ],
  "firstFeedback": [
    {
      "heading": "A clear mind is not required",
      "text": "The shopping thought may remain. Sky can choose a reading point and begin while thoughts are present. Trying to achieve no thoughts changes the goal from returning to controlling the mind."
    },
    {
      "heading": "This names a concrete point of return",
      "text": "Sky has something specific to re-engage with: the opening-times sentence. Choosing and reading those words demonstrates the return. It does not prove future concentration or require task completion."
    },
    {
      "heading": "Restarting is an option, not a penalty",
      "text": "Sky can reread any useful part if the meaning was missed. Repeating everything as punishment adds pressure and is not the skill. A chosen sentence or a pause can be enough."
    }
  ],
  "nextStage": "See what changes for Sky",
  "adaptHeading": "Returning is a choice, not an obligation",
  "changedContext": "A housemate now asks Sky a practical question. Sky wants to answer before continuing the notice. The interruption is relevant, not simply something to push away.",
  "adaptTask": "Choose a response that accounts for the interruption. Attention does not always have to return immediately to the original task.",
  "secondOptions": [
    "Answer the question, then decide whether to return to the marked sentence or pause.",
    "Ignore the housemate because any change of attention means failure.",
    "Decide that being interrupted proves the exercise did not work."
  ],
  "secondFeedback": [
    {
      "heading": "This makes room for a deliberate change",
      "text": "Sky can respond to the housemate, then choose what fits next. A place marker can help if Sky returns. Flexibility includes deciding that another task or a break matters now."
    },
    {
      "heading": "The exercise does not outrank a relevant need",
      "text": "Not every interruption should be ignored. Sky can decide what deserves attention. The aim is flexible re-engagement, not rigid persistence at any cost."
    },
    {
      "heading": "An interruption does not measure success",
      "text": "This page does not assess concentration or whether an exercise works for someone. Sky can notice the change, choose a response and decide whether to continue, adapt or stop."
    }
  ],
  "continuation": "Sky can answer the housemate, then return to the chosen sentence if reading still fits. Sky can also leave a marker and pause. Neither choice requires eliminating the shopping thought.",
  "freshHeading": "Try a return in your own way",
  "freshContext": "Lee chooses to read a short fictional garden note. You can use the reading task below, listen to it with support or simply rehearse Lee\u2019s next action. If attention moves, notice it and choose a place to return. If it does not move, you can still choose a starting point; do not manufacture a distraction.",
  "ownHeading": "Choose an ordinary task",
  "ownContext": "Choose a safe, low-stakes activity you want to engage with, or invent a learner. Name a particular part to return to if attention moves. You can change the task or pause for access needs, fatigue or discomfort. Do not use this to override a relevant concern or ongoing clinical guidance.",
  "practiceTask": "Try the reading task if you wish, then describe your own return. Think, talk or use the optional boxes. Leave any part open. There is no timer, count, focus score or required repetition; the model stays closed until review.",
  "fields": [
    {
      "label": "The chosen task",
      "hint": "What ordinary activity did you choose? Fiction or a spoken rehearsal is fine."
    },
    {
      "label": "What I noticed",
      "hint": "Where did attention go, if anywhere? No drift also needs no explanation."
    },
    {
      "label": "My specific return or other choice",
      "hint": "Which words or task detail did you return to? Or what made a pause or change fit?"
    },
    {
      "label": "Something useful to review",
      "hint": "Was the return point clear? What access change, support or next choice might help?"
    }
  ],
  "processHelp": "Replace \u201cconcentrate harder\u201d with something you could do: read from the next sentence or return to a named part of the task. A return can happen while thoughts remain. If the activity or opportunity does not fit, describe the change or pause instead. Do not count drift as failure or use the task to ignore an important need.",
  "reviewHeading": "Keep a useful return",
  "takeaway": "Notice without blame. Choose what matters now. Return to something specific, or change or pause when that fits.",
  "reviewChecks": [
    "Did I choose a specific task detail rather than demand a blank mind?",
    "Could I allow thoughts to remain and choose again if attention moved?",
    "Did I leave room for a relevant interruption, access need or a pause?"
  ],
  "reviewHelp": [
    {
      "heading": "My return is still vague",
      "text": "Name the exact words or next task detail. In the garden note,\u201cstart from The gate\u201d supplies a point to re-engage with;\u201cpay more attention\u201d does not say what to do."
    },
    {
      "heading": "I tried to stop every thought",
      "text": "A return does not require suppressing a thought. Notice that attention moved, then choose a task detail or a pause. The thought can remain without becoming the next task."
    },
    {
      "heading": "The task did not fit",
      "text": "Check access, fatigue, the setting or discomfort. A larger font, shared reading, a different ordinary task, support or stopping may fit better. This page cannot determine why attention is difficult."
    },
    {
      "heading": "I made a chosen return",
      "text": "Describe the action and what was useful. You do not have to finish the passage, count returns or feel better. If attention moves again, you can choose again or leave the exercise."
    }
  ],
  "freshModel": [
    "Chosen task: read Lee\u2019s fictional garden note.",
    "Noticed: planning another task while reading, if that happened. No drift is also possible.",
    "One return: choose \u201cThe gate\u201d and read that sentence, allowing other thoughts to remain. If continuing does not fit, pause.",
    "Review: was the starting point clear? Would a different format or task fit better?"
  ],
  "modelLimit": "One original example, not an assessment of your attention or notes. Your return point or choice to pause can differ. No drift needs to be created and no score is produced.",
  "finish": "A chosen return is an action you can try, not a demand for continuous concentration. You can leave it here."
};
config.ownCopy={
  "practiceTask": "Choose one specific part of your own safe, ordinary activity. If continuing fits, try returning to that part, or rehearse the action in your preferred way. A relevant interruption, access need or pause can change the choice. Think, talk or use the optional boxes; no timer, score or repetition is required.",
  "processHelp": "Replace “concentrate harder” with a specific action in your chosen task. Thoughts can remain. If the task or opportunity does not fit, describe a change or pause instead; do not use this to ignore an important need.",
  "reviewChecks": [
    "Did I choose a specific task detail rather than demand a blank mind?",
    "Could I allow thoughts to remain and choose again if attention moved?",
    "Did I leave room for a relevant interruption, access need or a pause?"
  ],
  "reviewHelp": [
    {
      "heading": "My return is still vague",
      "text": "Name one specific part of your chosen activity and what returning would involve. You can pause or change the task if continuing does not fit; you do not need to use the fictional reading passage."
    },
    {
      "heading": "I tried to stop every thought",
      "text": "A return does not require suppressing a thought. Notice that attention moved, then choose a task detail or a pause. The thought can remain without becoming the next task."
    },
    {
      "heading": "The task did not fit",
      "text": "Check access, fatigue, the setting or discomfort. A different format, a manageable task detail, support, a change of activity or stopping may fit. This page cannot determine why attention is difficult."
    },
    {
      "heading": "I made a chosen return",
      "text": "Describe the action you chose and what was useful in your task. You do not have to finish the activity, count returns or feel better. If attention moves again, you can choose again or leave the exercise."
    }
  ]
};
const renderAttention=helpers=>renderAttentionFlow(helpers,config);

return {renderAttention};})();
M["repair-practice.js"]=(function(){
function renderRepairPractice({el,p,button},c,state,mode='write'){
 if(!c.repair)return null;if(!document.querySelector('link[href="practice-support.css"]'))document.head.append(el('link',{rel:'stylesheet',href:'practice-support.css'}));const r=c.repair,root=el('section',{class:'support-context repair-practice'});
 function draw(){root.replaceChildren(el('h3',{},r.heading),p(r.context),p(r.prompt),...(mode==='write'?[el('label',{},'My revised wording (optional)',el('textarea',{rows:3,maxlength:1200,autocomplete:'off',oninput:e=>{state.attempt=e.target.value;state.reviewed=false;}},state.attempt))]:[p('Think, talk, sign or use another communication method. No writing is needed.')]),button('Review my repair',()=>{state.reviewed=true;draw();root.querySelector('.repair-review')?.focus();}));if(state.reviewed)root.append(el('section',{class:'repair-review support-feedback',tabindex:'-1'},el('h4',{},'Try and review usability'),p(r.trial),el('ul',{},...r.checks.map(x=>el('li',{},x))),p('These prompts do not assess your words or feelings.'),el('details',{},el('summary',{},'Compare with one possible repair'),p(r.model)),el('details',{},el('summary',{},'If the repair still feels stuck'),p(r.help)),...(mode==='write'?[el('label',{},'What I noticed or would revise (optional)',el('textarea',{rows:2,maxlength:1200,autocomplete:'off',oninput:e=>state.trial=e.target.value},state.trial))]:[])));}draw();return root;
}
function renderLaterReview({el,p},c,state,mode='write'){
 if(!c.laterReview)return null;return el('details',{class:'support-context later-review'},el('summary',{},'Later: review an agreed opportunity'),p('Only after an opportunity agreed with your clinician, or using fiction. Leave this blank if not tried. No effect, partial attempts and later information can be discussed without a score. This page does not retain a diary across visits.'),...c.laterReview.map((f,i)=>el('section',{},el('label',{},f.label,...(mode==='write'?[el('textarea',{rows:3,maxlength:1200,autocomplete:'off',oninput:e=>{state.later[i]=e.target.value;state.onChange?.();}},state.later[i])]:[])),p(f.hint))),p('Agree when/how/with whom to review. Optional written entries can be chosen separately for download; nothing is sent or assessed.'));
}

return {renderRepairPractice,renderLaterReview};})();
M["practice-support.js"]=(function(){const {renderRepairPractice,renderLaterReview}=M["repair-practice.js"];
const {landingChoices}=M["landing-choices.js"];
const {selectedNotes}=M["selected-notes.js"];



let plainLandingOwner;

// Shared interaction structure for bounded practice-planning support.
// Each skill supplies its own clinical target, examples, transfer and feedback.
function renderPracticeSupport({main,el,p,button},c){
 if(!document.querySelector('link[href="practice-support.css"]'))document.head.append(el('link',{rel:'stylesheet',href:'practice-support.css'}));
 const plainLanding=c.id==='self-kindness'&&c.landing;
 const life=new AbortController(),kept=new Set();
 if(plainLanding){const owner={};plainLandingOwner=owner;document.body.dataset.plainLanding=c.id;if(!document.querySelector('link[href="plain-landing.css"]'))document.head.append(el('link',{rel:'stylesheet',href:'plain-landing.css'}));life.signal.addEventListener('abort',()=>{if(plainLandingOwner===owner){delete document.body.dataset.plainLanding;plainLandingOwner=undefined;}},{once:true});}let view=location.hash.startsWith('#play/')?'example':'intro',first=null,second=null,help=null,kind='fresh',mode='write',reviewed=false;const notes=c.fields.map(()=> '');
 const extra={attempt:'',trial:'',reviewed:false,later:['','','','']};const clearExtra=()=>{extra.attempt=extra.trial='';extra.reviewed=false;extra.later.fill('');};
 const clear=()=>{clearExtra();notes.fill('');kept.clear();first=second=help=null;kind='fresh';mode='write';reviewed=false;};const dispose=()=>{clear();life.abort();};addEventListener('hashchange',dispose,{signal:life.signal});addEventListener('pagehide',dispose,{signal:life.signal});
 const actions=(...nodes)=>el('div',{class:'actions'},...nodes),h=text=>el('h2',{tabindex:'-1'},text),detail=(name,...nodes)=>el('details',{},el('summary',{},name),...nodes);
 const link=(text,href)=>el('a',{class:'button',href,target:href.startsWith('#')?'_self':'_blank',rel:'noopener'},text);
 const quote=(who,text)=>el('blockquote',{class:'support-message'},el('span',{class:'eyebrow'},who),p(text));
 const art=()=>el('figure',{class:'support-art'},el('img',{src:c.image,width:1536,height:1024,alt:c.alt}),el('figcaption',{},c.caption));
 function go(next){view=next;draw();(view==='intro'?main.querySelector('h1'):main.querySelector('h2[tabindex]'))?.focus({preventScroll:true});scrollTo(0,0);}
 const home=document.querySelector('#exercise-home'),finish=document.querySelector('#exercise-finish');if(home){home.setAttribute('aria-label','Practice Room - return to introduction; keep current notes');home.onclick=e=>{e.preventDefault();go('intro');};}if(finish)finish.onclick=()=>{clear();go('finished');};
 function picks(items,current,fn){return el('div',{class:'support-options'},...items.map((t,i)=>el('button',{type:'button','aria-pressed':String(current===i),onclick:()=>{fn(i);draw();main.querySelector('.support-feedback')?.focus();}},t)));}
 function feedback(data,i){return el('section',{class:'support-feedback',role:'status',tabindex:'-1'},el('h3',{},data[i].heading),p(data[i].text));}
 function progress(){const phase=view==='lesson'?0:['example','adapt'].includes(view)?1:['practice','switch','mode'].includes(view)?2:3;return el('ol',{class:'pmr-journey','aria-label':'Exercise sections'},...['Learn','Try an example','Your rehearsal','Take away'].map((t,n)=>el('li',n===phase?{'aria-current':'step'}:{},el('span',{},String(n+1).padStart(2,'0')),t)));}
 function field(f,i){return el('div',{class:'support-field'},el('label',{for:'support-note-'+i},f.label),el('p',{class:'meta',id:'support-hint-'+i},f.hint),...(mode==='write'?[el('textarea',{id:'support-note-'+i,rows:3,maxlength:1200,autocomplete:'off','aria-describedby':'support-hint-'+i,oninput:e=>{notes[i]=e.target.value;reviewed=false;help=null;}},notes[i])]:[p('Think, talk, sign or use another communication method. Nothing is recorded.')]));}
 const situationCopy=key=>kind==='own'&&c.ownCopy?.[key]!==undefined?c.ownCopy[key]:c[key];
 function draw(){main.replaceChildren();const root=el('div',{class:'values-module support-module','data-view':view,'data-skill':c.id});main.append(root);root.append(el('p',{class:'eyebrow'},'Teaching review / '+c.tag));
 if(view==='intro'&&plainLanding){
 root.append(el('section',{class:'plain-landing'},el('h1',{tabindex:'-1'},c.title),el('p',{class:'plain-purpose'},c.landing.purpose),el('p',{class:'plain-fit'},c.landing.fit),el('p',{class:'plain-essential'},c.landing.essential),landingChoices({el,button,learn:()=>go('lesson'),practice:()=>go('example')}),el('p',{class:'plain-access'},'Read, think or communicate in your preferred way. Writing is optional.'),detail('Is this right for me?',p(c.intro),p(c.boundary),p('Speaking, signing, AAC and shared reading are welcome.')),detail('Written versions and privacy',p('Rehearsal choices and notes stay in this page’s memory. Returning to this introduction keeps rehearsal notes; finishing, refreshing or leaving clears them. The separate optional application plan clears when you return here. Downloaded copies remain where you save them and may sync through your device settings.'),actions(link('Readable teaching handout',c.id+'-readable-handout.html'),link('Teaching card (PDF)',c.id+'-teaching-card.pdf'),link('Teaching card and optional worksheet (PDF)',c.id+'-teaching-and-practice.pdf'))),art(),...(notes.some(Boolean)?[p('Your current rehearsal notes are still available.'),actions(button('Return to my rehearsal',()=>go('practice')))]:[])));return;}
 if(view==='intro'){
 root.append(el('div',{class:'values-hero'},el('section',{},el('h1',{class:'pmr-hero-title',tabindex:'-1'},c.hero[0],el('em',{},c.hero[1])),p(c.lead),el('p',{class:'meta'},'About 5–10 minutes · Read, think, talk or write'),landingChoices({el,button,learn:()=>go('lesson'),practice:()=>go('example')})),art()),el('section',{class:'values-intro-note'},h(c.introHeading),p(c.intro),p(c.boundary),detail('Privacy and optional materials',p('Choices and notes stay in this page’s memory. Returning here keeps notes; finishing, refreshing or leaving clears them. Downloaded copies remain where you save them and may sync through your device settings.'),actions(link('Readable teaching handout',c.id+'-readable-handout.html'),link('Teaching card (PDF)',c.id+'-teaching-card.pdf'),link('Teaching card and optional worksheet (PDF)',c.id+'-teaching-and-practice.pdf'))),...(notes.some(Boolean)?[p('Your current rehearsal notes are still available.'),actions(button('Return to my rehearsal',()=>go('practice')))]:[])));return;}
 root.append(el('h1',{},c.title),progress());const b=el('section',{class:'activity-board values-board support-board'});root.append(b);
 if(view==='lesson'){
 b.append(h(c.lessonHeading),el('ol',{class:'support-lesson'},...c.lesson.map(x=>el('li',{},el('strong',{},x.heading),p(x.text)))),quote('One fictional example',c.exampleModel),p(c.lessonLimit),...(c.refresher?[detail(c.refresher.heading,p(c.refresher.text),actions(link(c.refresher.label,c.refresher.url)))]:[]),detail('Planned demonstration — storyboard, not a finished video',p('The written teaching and examples are complete. The storyboard and script describe a possible future video; no finished video or audio is available.'),actions(link('Read the storyboard and script',c.id+'-storyboard.html'))),actions(button(c.beginExample,()=>go('example'),true),button('Try a fresh rehearsal',()=>go('practice')),button('Finish without practising',()=>go('review'))));
 }else if(view==='example'){
 b.append(h(c.exampleHeading),el('div',{class:'support-example'},art(),el('div',{},p(c.exampleContext))),p(c.exampleTask),picks(c.firstOptions,first,i=>first=i));if(first!==null)b.append(feedback(c.firstFeedback,first));b.append(actions(button(first===null?'Read a possible approach and what changes':c.nextStage,()=>go('adapt'),true),button('Try a fresh rehearsal',()=>go('practice')),button('Finish with this example',()=>go('review'))));
 }else if(view==='adapt'){
 b.append(h(c.adaptHeading),quote('The starting point',c.exampleModel),p(c.changedContext),p(c.adaptTask),picks(c.secondOptions,second,i=>second=i));if(second!==null)b.append(feedback(c.secondFeedback,second));b.append(detail('Read one possible continuation',p(c.continuation)),actions(button('Try a fresh rehearsal before seeing a model',()=>go('practice'),true),button('Revisit the first choices',()=>go('example')),button('Finish with this example',()=>go('review'))));
 }else if(view==='switch'){
 if(plainLanding&&kind==='fresh')b.append(el('section',{class:'plain-own-boundary'},h('Before using your own situation'),p(c.landing.fit),p(c.boundary)));
 b.append(h(kind==='fresh'?'Use your own situation?':'Return to the fictional rehearsal?'),p('Changing the situation clears your current notes and download selections. Go back to review or download them first if you want to keep them.'),actions(button('Clear notes and change the situation',()=>{notes.fill('');kept.clear();clearExtra();help=null;reviewed=false;kind=kind==='fresh'?'own':'fresh';go('practice');},true),button('Keep my current rehearsal',()=>go('practice'))));
 }else if(view==='mode'){
 b.append(h('Change how you rehearse?'),p('Switching to thinking or talking clears written notes and download selections. You can go back to review or download them first.'),actions(button('Clear written notes and think or talk',()=>{notes.fill('');kept.clear();clearExtra();help=null;mode='spoken';go('practice');},true),button('Keep writing',()=>go('practice'))));
 }else if(view==='practice'){
 if(plainLanding&&kind==='own')b.append(el('section',{class:'plain-own-boundary'},h('Before using your own situation'),p(c.landing.fit),p(c.boundary)));
 if(c.repair)b.append(detail(c.repair.sectionLabel||'Separate worked-repair example',p('This worked repair has its own example and response box. After trying or skipping it, use the named fresh or own situation below for the main rehearsal.'),renderRepairPractice({el,p,button},c,extra,mode)));
 b.append(h(kind==='fresh'?c.freshHeading:c.ownHeading),...(kind==='fresh'?[el('section',{class:'support-context'},el('h3',{},'A different fictional situation'),p(c.freshContext))]:[p(c.ownContext)]),p(situationCopy('practiceTask')),p('Read to understand the method; try the short rehearsal to practise it. The prompts and model help you check it yourself. They do not assess your words or establish that you have learned the skill.'),...(c.fieldScope?[el('section',{class:'support-response-target','aria-label':'Situation for the four response fields'},h(kind==='fresh'?c.fieldScope.freshHeading:c.fieldScope.ownHeading),p(kind==='fresh'?c.fieldScope.freshReminder:c.fieldScope.ownReminder))]:[]),...c.fields.map(field),detail('Help with the method',p(situationCopy('processHelp'))),actions(button('Check my rehearsal myself',()=>{reviewed=true;go('review');},true),button(kind==='fresh'?'Use my own situation':'Use the fictional situation',()=>go('switch')),button(mode==='write'?'Change to thinking or talking':'Use optional writing boxes',()=>{if(mode==='write')go('mode');else{mode='write';go('practice');}}),button('Revisit the example',()=>go('example')),button('Finish without adding an answer',()=>{reviewed=true;go('review');})));
 }else if(view==='review'){
 b.append(h(c.reviewHeading),p(c.takeaway),...(c.fieldScope?[el('section',{class:'support-response-target','aria-label':'Situation for the reviewed main responses'},h(kind==='fresh'?c.fieldScope.freshHeading:c.fieldScope.ownHeading),p(kind==='fresh'?c.fieldScope.freshReminder:c.fieldScope.ownReminder))]:[]),...(notes.some(Boolean)?[el('section',{class:'support-recap'},el('h3',{},'Your optional rehearsal notes'),...c.fields.map((f,i)=>el('div',{},el('strong',{},f.label),p(notes[i]||'Left open.'))))]:[p('No written response is needed. You can keep the method, return to rehearse or leave it here.')]),...(reviewed?[el('section',{class:'support-context'},el('h3',{},'Review the rehearsal yourself'),el('ul',{},...situationCopy('reviewChecks').map(t=>el('li',{},t))),p('These prompts do not assess your words. You can revise any part, choose support or decide not to continue.')),el('h3',{},'If one part needs attention'),p('Choose an area for a process suggestion. This does not analyse your notes.'),picks(situationCopy('reviewHelp').map(x=>x.heading),help,i=>help=i)]:[]));if(reviewed&&help!==null)b.append(feedback(situationCopy('reviewHelp'),help));
 if(reviewed&&kind==='fresh')b.append(detail('Compare with one possible rehearsal',el('ol',{},...c.freshModel.map(t=>el('li',{},t))),p(c.modelLimit)));
 const getEntries=()=>[...c.fields.map((f,id)=>({id,label:f.label,value:notes[id]})),...(c.repair?[{id:'repair',label:(c.repair.sectionLabel||'Separate worked repair')+' — my repair wording',value:extra.attempt},{id:'trial',label:(c.repair.sectionLabel||'Separate worked repair')+' — trial and revision',value:extra.trial}]:[]),...(c.laterReview?c.laterReview.map((f,i)=>({id:'later'+i,label:f.label,value:extra.later[i]})):[])];const exportHost=el('div',{class:'support-extra-export'});const refreshExport=()=>{exportHost.replaceChildren();const allEntries=getEntries();if(mode==='write'&&allEntries.some(e=>e.value.trim()))exportHost.append(selectedNotes({title:c.title+' - my rehearsal',entries:allEntries,selected:kept,filename:c.id+'-my-rehearsal.txt'}));};extra.onChange=refreshExport;if(c.laterReview)b.append(renderLaterReview({el,p},c,extra,mode));b.append(exportHost);refreshExport();
 b.append(actions(button('Return to my rehearsal',()=>go('practice')),button('Return to introduction; keep notes',()=>go('intro')),button('Finish and clear this exercise',()=>{clear();go('finished');},true),link('Teaching card (PDF)',c.id+'-teaching-card.pdf'),link('Optional worksheet (PDF)',c.id+'-teaching-and-practice.pdf'),link('One possible everyday use and agreed review','application-'+c.id+'.html')));
 }else if(view==='finished'){
 b.append(h('You can leave it here'),p('Your choices and on-page notes have been cleared. Downloaded or printed copies remain where you saved them.'),p(c.finish),actions(button('Return to the introduction',()=>go('intro'),true),link('Return to therapist library','#library')));
 }
 }
 draw();
}

return {renderPracticeSupport};})();
M["making-room.js"]=(function(){const {renderPracticeSupport}=M["practice-support.js"];

const config={
  "id": "making-room",
  "title": "Making room for a feeling",
  "hero": [
    "Making room",
    " for a feeling"
  ],
  "tag": "Acceptance of ordinary feelings",
  "image": "media/making-room/choices.png",
  "alt": "Three panels labelled acknowledge a feeling, allow choice, and respond with care.",
  "caption": "Original method diagram. Allowing a feeling does not mean approving a situation.",
  "lead": "Acknowledge an ordinary feeling without needing to remove it before choosing a response. You can allow a feeling and still set a boundary, ask for support or leave a situation.",
  "introHeading": "Allow the feeling; keep your choices",
  "intro": "For therapist-supported adults exploring ordinary disappointment or frustration. Use fiction first. Practise words that acknowledge a feeling without ordering it away, then choose a feasible response. Quiet thought, speech, optional writing, a pause or stopping can fit.",
  "boundary": "Acceptance does not mean agreeing with harm, tolerating abuse, acting on an urge or giving up practical support. Not a trauma, dissociation, crisis or pain-treatment protocol. No inward body focus, breathing exercise, imagery, touch or enduring distress is required. Use fiction or stop if unsuitable.",
  "lessonHeading": "Acknowledge, allow and choose",
  "lesson": [
    {
      "heading": "Acknowledge what is here, tentatively.",
      "text": "Use your own words, such as \"There is disappointment\" or \"Something feels difficult.\" A precise label is optional. Do not search for a bodily sensation or recall a painful event to make the feeling stronger."
    },
    {
      "heading": "Make allowance without a bargain.",
      "text": "Try \"I do not have to settle this feeling before choosing my response.\" This is an invitation, not a demand to accept. The feeling may stay, shift or be unclear; none proves success or failure."
    },
    {
      "heading": "Choose your response to the situation.",
      "text": "A feeling and an urge do not dictate the next action. Consider a boundary, practical step, rest, support or stopping. Allowing frustration does not require sending an angry message or remaining in an unsuitable situation."
    }
  ],
  "exampleModel": "A cancelled art session leaves Noor disappointed. Noor tries: \"Disappointment is here; I do not have to make it disappear before deciding what I need.\" Noor chooses to ask about the next session or take a break. The cancellation is not declared acceptable.",
  "lessonLimit": "This teaches an original, words-based acceptance rehearsal for ordinary feelings, not the full WHO experiential sequence or a requirement to feel more. Self-kindness and emotion naming remain separate skills.",
  "beginExample": "Explore Noor's possible response",
  "exampleHeading": "Which response allows a feeling and keeps choice?",
  "exampleContext": "An ordinary art session is cancelled. Noor feels disappointed and has an urge to send a sharp message. The organiser has not given another date. The example does not involve harm or an urgent need.",
  "exampleTask": "Choose words that acknowledge disappointment without forcing it away or treating the urge as an instruction.",
  "firstOptions": [
    "I will allow disappointment for a moment so it will leave and I can get on with things.",
    "Disappointment is here; I can decide whether to ask about another date, take a break or seek support.",
    "I can accept the feeling by putting the cancellation out of my mind until I feel ready."
  ],
  "firstFeedback": [
    {
      "heading": "Allowance has become a bargain for relief",
      "text": "The wording permits the feeling only if it leaves. Try allowing uncertainty about whether it changes, while choosing a response or pause. This is optional; you do not have to endure or intensify it."
    },
    {
      "heading": "This leaves room for feeling and response choice",
      "text": "The words acknowledge disappointment without promising relief. Asking, taking a break or support are options; the cancellation does not have to be endorsed."
    },
    {
      "heading": "Putting it out of mind is a different aim",
      "text": "You may choose a break, but acceptance here does not require stopping awareness of the feeling. Acknowledge it tentatively and keep a practical response, boundary or support available."
    }
  ],
  "nextStage": "Separate acceptance from giving up",
  "adaptHeading": "A practical need can still matter",
  "changedContext": "Noor learns that the cancelled session fee has not been refunded as expected. Noor is still disappointed and wants clear information about the refund.",
  "adaptTask": "Choose a response that allows feeling without surrendering a practical need.",
  "secondOptions": [
    "Acceptance means I must never ask for the refund.",
    "I can acknowledge disappointment and ask a clear refund question, or get help doing so.",
    "The refund question must wait until I feel completely calm."
  ],
  "secondFeedback": [
    {
      "heading": "Acceptance does not cancel a practical need",
      "text": "The fee question remains relevant. Allowing a feeling is not giving up rights, support or action. The page does not decide what refund is owed."
    },
    {
      "heading": "A feeling and a practical step can coexist",
      "text": "Noor can seek information or support while disappointed. A boundary or pause also remains available; the tool does not require contacting anyone."
    },
    {
      "heading": "Complete calm is not a prerequisite",
      "text": "Noor can choose a suitable response or pause without a perfect emotional state. If the situation is too much, human support can help; this rehearsal is optional."
    }
  ],
  "continuation": "Noor can say, \"I am disappointed, and I still need information about the fee.\" A clear question, help from someone trusted, or a pause can fit. No refund outcome or reduction in feeling is promised.",
  "freshHeading": "Try words of allowance before a model",
  "freshContext": "Fictional example: Jules planned to read in the garden, but heavy rain prevents it. Jules feels frustrated and has an urge to abandon the whole afternoon. Reading indoors, resting or doing something else are possible; none is compulsory.",
  "ownHeading": "Choose an ordinary feeling only if it fits",
  "ownContext": "Use a mild everyday example already suitable in therapy, or invent one. You do not need to recall trauma, intensify a feeling or attend inside your body. Keep any details private, use broad words or stop. Actual harm or urgent needs call for appropriate human support, not acceptance of the situation.",
  "practiceTask": "Create one phrase that acknowledges the feeling, a phrase that leaves it room without a relief target, and a chosen response. Include a boundary or pause if useful. Think or talk instead of writing; feeling better is not the test.",
  "fields": [
    {
      "label": "A feeling, broadly or tentatively",
      "hint": "Use your own words, \"not sure\" or a fictional example; no body search."
    },
    {
      "label": "Words that allow rather than order away",
      "hint": "For example, I do not have to settle this feeling before choosing a response."
    },
    {
      "label": "A response I can choose",
      "hint": "Separate the feeling/urge from a boundary, practical step, rest or support."
    },
    {
      "label": "Hidden bargain, boundary or adaptation",
      "hint": "Am I allowing only to get relief? Try wording briefly if useful; keep boundaries, support and stopping available."
    }
  ],
  "processHelp": "For Jules, frustration can be acknowledged without calling it wrong or requiring it to disappear. Choosing indoor reading, rest or another activity does not mean liking the rain. A pause is also available. Avoid wording that turns allowance into another obligation.",
  "reviewHeading": "Allow a feeling without surrendering choice",
  "takeaway": "Acknowledge the feeling, make room without a bargain for relief, and choose a response. Acceptance of a feeling is different from approval of a situation or following an urge.",
  "reviewChecks": [
    "Does my wording acknowledge rather than shame, dismiss or order away a feeling?",
    "Am I allowing uncertainty about whether the feeling changes?",
    "Have I kept practical needs, boundaries, support and stopping available?"
  ],
  "reviewHelp": [
    {
      "heading": "My phrase tells me to feel differently",
      "text": "Try a tentative acknowledgement instead of a command: \"Frustration is here.\" You may use neutral words or leave it unnamed. No particular phrase is required."
    },
    {
      "heading": "I expected relief as proof",
      "text": "The feeling may remain or change. The rehearsal concerns how you respond, not achieving a distress score. You can stop if it is not useful."
    },
    {
      "heading": "I confused allowance with approval",
      "text": "Name what you do not have to accept about the situation. Practical support, boundaries and protective action still matter."
    },
    {
      "heading": "The exercise feels like pressure",
      "text": "Decline or use the fictional example. Willingness cannot be forced; no inward focus, endurance or disclosure is required."
    }
  ],
  "freshModel": [
    "Feeling: Jules notices frustration about the rain, or can leave it broadly described.",
    "Allowance: \"This is frustrating; I do not need to remove that feeling before choosing what I need.\"",
    "Response: Jules could read indoors, rest or choose something else.",
    "Review: no relief is required. If \"so it goes away\" has crept in, try \"whether or not the frustration changes.\" Keep a boundary or pause and discuss pressure/fit at the next agreed therapy review."
  ],
  "modelLimit": "One original words-based example, not an assessment, required script or full acceptance protocol. No symptom change, disclosure or action is required.",
  "finish": "You can leave with words, a boundary, a question or no answer. Choosing to stop is available.",
  "repair": {
    "heading": "Notice and repair a hidden bargain",
    "context": "Jules tries, \"I will allow this frustration so I can make it go away.\" The words sound like acceptance, but relief has become the condition.",
    "prompt": "Create words that leave the ordinary feeling free to stay, change or be unclear, without approving the situation. Choose one possible response or pause.",
    "model": "\"Frustration is here. It does not have to change before I choose whether to read indoors, rest or do something else.\"",
    "trial": "Use the mild fictional example, or an ordinary feeling already suitable in therapy. Try the words briefly if useful. Notice any pressure to get relief; change the words, use fiction or stop. No body focus, imagery, endurance or emotional result is required.",
    "checks": [
      "Is relief a hoped-for possibility or a requirement for permission?",
      "Can the feeling remain while a practical need or boundary still matters?",
      "Is a pause/support or declining the exercise available?"
    ],
    "help": "If you notice \"so it goes away,\" try \"whether or not it changes\" or neutral acknowledgement. Willingness is not forced. Discuss the pressure or fit with your therapist."
  }
};
const renderRoom=helpers=>renderPracticeSupport(helpers,config);

return {renderRoom};})();
window.SettleRecoveredModules=M;
M["self-kindness.js"]=(function(){const {renderPracticeSupport}=M["practice-support.js"];

const config={
  "landing": {"purpose":"Describe a difficult moment without attacking yourself. Try words that are honest and respectful.","fit":"Use a small difficulty you have discussed with your therapist, or a made-up example.","essential":"The words do not have to feel warm. You can pause or stop."},
  "id": "self-kindness",
  "title": "A kinder response to yourself",
  "hero": [
    "A kinder response",
    " to yourself"
  ],
  "tag": "Respectful self-response",
  "image": "media/self-kindness/quinn.png",
  "alt": "Quinn sits at a home desk with an open notebook, an envelope and a cup.",
  "caption": "Quinn considers an ordinary oversight. Original generated concept art, not video.",
  "lead": "Acknowledge what is difficult without turning an action into an attack on yourself. Try wording that is respectful, realistic and useful, even if it does not feel warm or reassuring.",
  "introHeading": "Kindness can stay honest",
  "intro": "For therapist-supported adults exploring self-critical wording around an ordinary, manageable difficulty. Compare responses to Quinn’s missed reply, then create a different response in your own words. Think, talk, write, skip or stop.",
  "boundary": "Kind wording can feel unfamiliar or uncomfortable. Use fiction, choose neutral respectful words, ask for support or stop. This page does not require forgiveness, positive affirmations or denying harm. It is not a treatment for severe shame or trauma, or a way to decide responsibility in abuse or danger.",
  "lessonHeading": "Acknowledge, respect, respond",
  "lesson": [
    {
      "heading": "Acknowledge the difficulty and its effect.",
      "text": "Describe what happened and why it matters. You can recognise disappointment, a mistake or another person’s inconvenience without saying it is unimportant."
    },
    {
      "heading": "Use words that respect the person.",
      "text": "Respond to the specific action or difficulty without a global attack such as “I ruin everything.” Neutral wording can fit: “I missed the reply, and that had an effect.” You do not have to believe a positive slogan."
    },
    {
      "heading": "Consider what support or next response fits.",
      "text": "Acknowledge an impact, consider a practical repair, ask for help or pause. Respectful language can include responsibility and limits. It cannot guarantee relief, undo the event or require another person to forgive."
    }
  ],
  "exampleModel": "“I missed the availability reply. That is frustrating and may have made planning harder. I can acknowledge it and ask whether there is anything useful to do now.”",
  "lessonLimit": "This is original brief wording rehearsal, not a full self-compassion treatment, thought diary or emotion-regulation protocol. No particular feeling, tone of voice, repetition or real-world action is required.",
  "beginExample": "Compare responses for Quinn",
  "exampleHeading": "Which reply stays respectful and realistic?",
  "exampleContext": "Quinn meant to send availability for a community event by Tuesday but forgot. The organiser has already planned the rota. Quinn thinks, “I ruin everything.” The missed reply may have caused extra work; this is an ordinary fictional oversight.",
  "exampleTask": "Choose a response. Look for acknowledgement without a personal attack or an attempt to erase the effect.",
  "firstOptions": [
    "I was doing my best, so there is no effect I need to acknowledge.",
    "I missed the reply. That may have made planning harder. I can acknowledge it and ask what would help now.",
    "I should be kinder to myself and make sure I get every reply right from now on."
  ],
  "firstFeedback": [
    {
      "heading": "Self-respect can include the actual effect",
      "text": "Recognising effort does not settle the impact. Add what happened and what may need attention without a global attack: the reply was missed and planning may have been harder."
    },
    {
      "heading": "This keeps both respect and responsibility",
      "text": "The wording names the missed reply and possible impact, then considers a specific question. It neither attacks Quinn’s identity nor guarantees that the organiser can change the rota. A neutral, respectful tone is enough."
    },
    {
      "heading": "A kind instruction can become another perfection demand",
      "text": "Future perfect replying is not promised. Try neutral wording about this event and a possible support or repair, rather than requiring yourself to feel kind and never make a mistake."
    }
  ],
  "nextStage": "See the organiser’s reply",
  "adaptHeading": "When the event cannot be undone",
  "changedContext": "The organiser says the rota is final and there is no task available this time. Quinn feels disappointed. A respectful response cannot create an available place.",
  "adaptTask": "Choose a continuation. More than one can fit; the feedback shows how responsibility, limits and disappointment can coexist.",
  "secondOptions": [
    "I can acknowledge the extra work and the final rota. I can be disappointed without attacking myself.",
    "I need a neutral pause: I missed the reply, the rota is final, and I can decide later whether a reminder would help.",
    "If I am kind enough to myself, the organiser has to give me a place."
  ],
  "secondFeedback": [
    {
      "heading": "This allows a consequence and a difficult feeling",
      "text": "Quinn does not have to feel better or get a different outcome. Acknowledging the effect and the organiser’s decision can coexist with treating oneself respectfully."
    },
    {
      "heading": "Neutral wording and a pause can fit",
      "text": "The reply stays factual and leaves a later practical choice open. Quinn need not manufacture warmth or turn self-kindness into an additional task. A reminder is an option, not a required routine."
    },
    {
      "heading": "Kindness does not control someone else’s decision",
      "text": "The rota remains the organiser’s decision. Self-respect cannot require a place or forgiveness. The target is how Quinn responds to the difficulty, including a limit that cannot be changed."
    }
  ],
  "continuation": "Quinn can acknowledge the inconvenience and the final decision, then choose a pause or a later reminder. Disappointment can remain. No insult, forced reassurance or guaranteed new opportunity is needed.",
  "freshHeading": "Create a different respectful response",
  "freshContext": "Ada knocks over a friend’s small plant pot and cracks it. Ada notices the thought, “I am useless.” The pot is damaged, and Ada does not yet know what repair would be wanted or affordable. This is fiction; no apology or purchase has to be made.",
  "ownHeading": "Respond to an ordinary difficulty",
  "ownContext": "Use a manageable example or invent a learner. Leave out private details. Acknowledge the event without making a judgement about your worth. If the issue involves trauma, coercion, serious harm or danger, leave the personal exercise and seek appropriate support; this page cannot decide blame or responsibility.",
  "practiceTask": "Before opening a model, say, think or write a respectful reply in your own words. You may use neutral language and leave any part open. There is no need to write out self-criticism first, feel warmth, promise a repair or carry out a live action. Use the case named immediately above the four response fields; the separate worked repair has its own response box.",
  "fields": [
    {
      "label": "The difficulty and its effect",
      "hint": "For Ada’s cracked-pot example, or the own situation you selected: Describe the event without an attack on the person. What matters about the effect?"
    },
    {
      "label": "A respectful, realistic reply",
      "hint": "What could acknowledge the difficulty without insults, denial or a positive slogan?"
    },
    {
      "label": "A possible response or support",
      "hint": "A repair question, help, a limit or a pause can fit. Do not promise what you cannot offer."
    },
    {
      "label": "Trial, usability and possible revision",
      "hint": "Try the respectful or neutral words briefly if useful. What fits, feels pressured or needs support? No warm feeling is required."
    }
  ],
  "processHelp": "Replace a global judgement with the specific event, then acknowledge why it matters. Add a respectful next response only if it fits. “The pot is cracked; I can ask what would be helpful” differs from both “I am useless” and “It does not matter.” Kindness does not erase an effect, force warmth or require an unaffordable promise.",
  "reviewHeading": "Keep words you can use",
  "takeaway": "Name what happened. Keep respect for the person. Consider support, repair, a limit or a pause. Difficult feelings and consequences can remain.",
  "reviewChecks": [
    "Does the wording acknowledge the event and effect without attacking the whole person?",
    "Does it stay realistic rather than deny harm or promise a positive outcome?",
    "Can I choose neutral words, support or a pause without forcing warmth or repair?"
  ],
  "reviewHelp": [
    {
      "heading": "The reply still attacks the person",
      "text": "Name the action instead of a global identity judgement. “I cracked the pot” says what happened; “I am useless” judges the whole person and does not identify a response."
    },
    {
      "heading": "The reply dismisses what happened",
      "text": "Add the effect back in: the pot is damaged, and the friend may be disappointed. Respectful words can acknowledge that without demanding forgiveness or making a promise."
    },
    {
      "heading": "Kind words feel too much",
      "text": "Try neutral facts: “This happened, it matters, and I can consider what fits next.” Use fiction, seek support or stop if even that is not useful. You do not need to manufacture a warm feeling."
    },
    {
      "heading": "I have a respectful draft",
      "text": "Check whether it is specific, realistic and usable in your own language. Consider a revision or pause. The tool does not judge your worth, assess the response or require relief."
    }
  ],
  "freshModel": [
    "Event and effect: Ada cracked the pot; the damage and the friend’s response matter.",
    "One reply: “I cracked the pot. That is upsetting, and an accident does not require calling myself useless.”",
    "Possible response: ask what would be helpful and consider what Ada can realistically offer; no immediate purchase or guaranteed forgiveness.",
    "Try the words once if useful. If they sound false, use: \"The pot cracked; the effect matters. I can ask what would help.\" Notice usability rather than demanding warmth. Bring an example of wording/pressure to an agreed therapy review."
  ],
  "modelLimit": "One original fictional response, not the correct script or an assessment of your notes. Wording, resources, relationships and responsibility differ. This is not a promise that a kinder sentence changes a feeling or another person’s reply.",
  "finish": "You can leave with a respectful sentence, a neutral description, a question for support or no answer. You do not need to feel better to stop.",
  "repair": {
    "heading": "Repair wording that sounds kind but is unusable",
    "context": "Quinn missed the availability reply; the organiser says the rota is final. Quinn tries, \"I am wonderfully organised and everyone understands,\" but cannot believe it. This worked repair concerns Quinn only.",
    "prompt": "Write, think or say a more believable neutral response. Acknowledge the missed reply and its impact without insults or forced warmth. Then try the words briefly, if useful.",
    "model": "\"I missed the reply and that affected planning. The rota is final. I can be disappointed and pause before deciding whether a reminder or support would help.\"",
    "trial": "Try the revised words once in a tone you can use, silently or aloud. What feels believable, awkward or like a demand? Revise or seek support; no warmer feeling is required.",
    "checks": [
      "Does the reply stay with this event and its effect?",
      "Could neutral words be usable even if warmth is unavailable?",
      "Would a pause or support fit better than forcing the phrase?"
    ],
    "help": "If the new words feel like another demand, shorten to neutral facts: \"I missed the reply; the rota is final.\" A question or supported pause can be enough.",
    "sectionLabel": "Separate worked repair: Quinn’s missed reply"
  },
  "fieldScope": {
    "freshHeading": "Now rehearse Ada’s cracked-pot example",
    "freshReminder": "Ada cracked a friend’s pot; its effect matters, and what repair is wanted or affordable is unknown. The four fields below concern this example, not the separate worked repair.",
    "ownHeading": "Now rehearse your chosen situation",
    "ownReminder": "The four fields below concern the ordinary situation you chose. The separate worked repair is finished; you do not need to answer about its characters."
  },
  "version": "1.2-reviewer-followup"
};
config.ownCopy={
  "practiceTask": "Before opening any comparison, think, say or write a respectful reply about the ordinary situation you chose. Neutral words, uncertainty or a pause can fit. No warmth, live action or repair promise is required.",
  "processHelp": "Describe your chosen event and why its effect matters without a global attack on yourself. Consider a response, support, a limit or a pause only if useful. Ada’s damaged pot is a separate fictional comparison, not part of your situation.",
  "reviewChecks": [
    "Does the wording acknowledge the event and effect without attacking the whole person?",
    "Does it stay realistic rather than deny harm or promise a positive outcome?",
    "Can I choose neutral words, support or a pause without forcing warmth or repair?"
  ],
  "reviewHelp": [
    {
      "heading": "The reply still attacks the person",
      "text": "Name the specific event or action in your chosen situation rather than judging the whole person. Keep what actually happened separate from an insult about your worth."
    },
    {
      "heading": "The reply dismisses what happened",
      "text": "Add back what actually happened and what effect matters in your chosen situation. Keep uncertainty where the effect is not known. Respectful words need not deny harm, demand forgiveness or promise a repair."
    },
    {
      "heading": "Kind words feel too much",
      "text": "Try neutral facts: “This happened, it matters, and I can consider what fits next.” Use fiction, seek support or stop if even that is not useful. You do not need to manufacture a warm feeling."
    },
    {
      "heading": "I have a respectful draft",
      "text": "Check whether it is specific, realistic and usable in your own language. Consider a revision or pause. The tool does not judge your worth, assess the response or require relief."
    }
  ]
};
const renderKindness=helpers=>renderPracticeSupport(helpers,config);

return {renderKindness};})();
M["defusion-media/content.js"]=(function(){
const content={"version": "0.4.1", "duration": 78, "examples": {"task": {"title": "Starting a piece of writing", "thought": "I’ll get it wrong.", "context": "You want to start a piece of writing, but hesitate over the first sentence.", "options": [["Write one rough sentence.", "This gives you something to work with. You can decide what to change afterward; it does not promise that the sentence will be good."], ["Make a few notes first.", "This may help you find a starting point before writing a sentence. The thought can still be present."], ["Ask for clarification.", "If you are unsure what the task asks for, more information may be useful. The phrase does not replace solving a practical problem."]]}, "walk": {"title": "An interrupted walk", "thought": "The whole walk was pointless.", "context": "Sam planned a loop walk for time outdoors. A large fallen tree blocks the trail, so the planned route cannot be completed.", "options": [["Retrace the path and notice the surroundings.", "This keeps some attention on the reason for coming out: time outdoors. Sam can still feel disappointed."], ["Head home and rest.", "Sam can decide to finish for today. There is no requirement to turn the interruption into a positive experience."]]}, "connection": {"title": "Reaching out to someone", "thought": "They’ll think I’m awkward.", "context": "You want to get back in touch with a friend, but hesitate over what to say.", "options": [["Draft a short hello.", "A draft gives you something to consider. You can decide later whether to send it, without knowing how your friend will respond."], ["Think about what I want to communicate.", "This may help clarify what matters to you before choosing words."], ["Leave the decision about sending for later.", "A pause can be a choice too. You do not have to send a message to finish this practice."]]}}, "cues": [[0, 7, "Sam planned a loop walk to spend some time outdoors."], [7, 14, "A fallen tree blocks the trail. Sam cannot finish the planned route."], [14, 21, "A thought arrives: “The whole walk was pointless.”"], [21, 30, "Try noticing it: “I’m having the thought that the whole walk was pointless.”"], [30, 38, "The blocked trail is a fact. “Pointless” is the judgement Sam’s mind adds."], [38, 46, "Sam does not have to argue with that thought, or stop feeling disappointed."], [46, 54, "The route needs to change. What could still serve the reason for coming out?"], [54, 63, "One option: retrace the path and notice the surroundings on the way back."], [63, 70, "Or head home and rest. There is no requirement to make this a good walk."], [70, 78, "The tree stays. The thought may stay. Sam can still choose how to respond."]], "description": "Sam planned a loop walk for time outdoors. A large fallen tree spans the trail, with tangled branches across both edges. It stays in place throughout. A thought bubble says “The whole walk was pointless.” The noticing phrase appears, and the bubble occupies less of the same scene. Two possible responses are shown: notice the surroundings while retracing the path, or head home and rest. Neither removes the tree or promises a change in feeling.", "observations": {"Some room to choose": "You can keep a reminder of what you tried if that would be useful.", "No difference": "There is no need to repeat until something changes. You can finish, or revisit the example if you want clarification.", "Uncomfortable": "You can stop here. There is no need to push through. Support and ending the exercise remain available.", "Not sure": "You do not need to decide what it means. You can finish or revisit the example."}};

return {content};})();
M["cognitive-defusion.js"]=(function(){const {printSelectedText}=M["selected-notes.js"];
const {landingChoices}=M["landing-choices.js"];
const {content}=M["defusion-media/content.js"];



const labels=['Situation and thought','Noticing words I tried','A response I considered','What I noticed or want to keep','What I noticed after trying the phrase'];
const noteOrder=[0,1,4,2,3];
const naming=thought=>'I’m having the thought that '+thought.replace(/^The /,'the ').replace(/^They/,'they');
const invitations=['Recall the everyday situation and the words your mind supplied.','Try naming the thought as a thought, if that fits.','Consider what the situation asks for, including rest, support or a practical step.','What, if anything, would you keep or discuss?','What changed about how the thought landed? What stayed the same?'];
function renderDefusion({main,el,p,button,entry}){
 let step=entry==='lesson'?'lesson':'intro',ownStep='thought',started=false,mode='write',words=['','','','',''],exampleId='walk',phrase=null,response=null,observation=null,reading=false,variation=null,variationThought='fictional',selected=new Set();
 let streamController=null;
 const lifecycle=new AbortController();
 const clear=()=>{words=['','','','',''];started=false;ownStep='thought';exampleId='walk';phrase=null;response=null;observation=null;variation=null;variationThought='fictional';selected.clear();};
 function stopMedia(){streamController?.dispose();streamController=null;for(const v of main.querySelectorAll('video')){v.pause();v.removeAttribute('src');v.load();}}
 function dispose(){stopMedia();clear();main.querySelectorAll('textarea').forEach(t=>t.value='');lifecycle.abort();}
 addEventListener('hashchange',dispose,{signal:lifecycle.signal});addEventListener('pagehide',dispose,{signal:lifecycle.signal});
 const row=(...n)=>el('div',{class:'actions'},...n),h=s=>el('h2',{tabindex:'-1'},s),link=(label,href)=>el('a',{class:'button',href,target:'_blank',rel:'noopener'},label);
 function go(s){stopMedia();step=s;if(['thought','notice','pause','respond','review'].includes(s))ownStep=s;draw();main.querySelector(s==='intro'||s==='finished'?'h1':'.values-board h2')?.focus();window.scrollTo(0,0);}
 function own(){go(started?ownStep:'mode');}
 function example(){phrase=null;response=null;reading=false;go('example-choose');}
 function pick(label,current,id,fn){return el('button',{type:'button',id,class:'values-choice','aria-pressed':String(current),onclick:()=>{fn();draw();document.getElementById(id)?.focus({preventScroll:true});}},el('span',{class:'values-selection','aria-hidden':'true'},current?'Selected':'Explore this'),el('span',{},label));}
 function feedback(title,text){return el('section',{class:'activity-feedback',role:'status'},el('h3',{},title),p(text));}
 function field(i,label,hint){return el('label',{class:'values-field'},label,el('span',{class:'meta'},hint),el('textarea',{id:'defusion-word-'+i,rows:'3',maxlength:'600',autocomplete:'off',oninput:e=>words[i]=e.target.value},words[i]));}
 function phraseCard(thought,noticing=false){return el('div',{class:'defusion-phrase'},el('p',{class:'meta'},noticing?'Naming the thought':'The thought as it arrives'),p(noticing?naming(thought):thought));}
 function recap(indices=noteOrder){return el('dl',{class:'values-recap'},indices.flatMap(i=>[el('dt',{},labels[i]),el('dd',{},mode==='spoken'?invitations[i]:words[i].trim()||'Left open.')]));}
 function selectedText(indices){return 'Step back from a thought — my selected notes\n\n'+indices.map(i=>labels[i]+'\n'+words[i].trim()).join('\n\n');}
 function download(indices){const a=document.createElement('a'),url=URL.createObjectURL(new Blob([selectedText(indices)],{type:'text/plain;charset=utf-8'}));a.href=url;a.download='Step-back-from-a-thought-my-notes.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
 function film(){return el('section',{class:'defusion-film'},el('h3',{},'Sam’s interrupted walk — written demonstration'),p('Source video and its recording are withheld in this local review. Read the complete authored demonstration below.'),...content.cues.map(c=>p(c[2])));}
 function secondary(){return el('div',{class:'values-secondary'},button('Return to introduction',()=>go('intro')),button(started?'Return to my practice':'Try my own situation',own),button('Choose a practice example',example),button('Take away or finish',()=>go('keep')));}
 const home=document.querySelector('#exercise-home'),exit=document.querySelector('#exercise-finish');if(home){home.setAttribute('aria-label','Practice Room — exercise introduction');home.onclick=e=>{e.preventDefault();go('intro');};}if(exit)exit.onclick=()=>go('keep');
 function draw(){
  main.replaceChildren(el('div',{class:'values-module defusion-module', 'data-view':step},el('p',{class:'eyebrow'},'Step back from thoughts / Cognitive defusion')));const root=main.firstChild;
  if(step==='intro'){
   root.append(el('section',{class:'values-hero'},el('div',{class:'defusion-intro-copy'},el('h1',{class:'defusion-hero-title',tabindex:'-1'},'Step back ',el('em',{},'from a thought')),el('p',{class:'defusion-skill-title'},'Cognitive defusion'),el('p',{class:'lead'},'Try noticing the words your mind supplies, then consider how you want to respond to the situation.'),p('You do not have to make the thought disappear.'),el('p',{class:'meta'},'About 5–10 minutes · Read, write, think or talk'),landingChoices({el,button,learn:()=>go('lesson'),practice:own,more:[button('Try Leaves on a Stream',()=>go('stream')),button('Watch the lesson video',()=>{go('lesson');const title=document.querySelector('#defusion-video-title');title?.focus();title?.scrollIntoView({block:'start'});}),button('Work through Sam’s example',()=>{exampleId='walk';phrase=null;response=null;go('example-notice');})]})),el('section',{class:'defusion-at-glance','aria-label':'An example of noticing a thought'},el('p',{class:'eyebrow'},'THE EXERCISE, AT A GLANCE'),el('h2',{},'Try. Pause. Notice.'),el('img',{src:'defusion-media/fallen-tree.png',alt:'A fallen tree blocks a woodland trail.'}),el('div',{class:'defusion-thought-pair'},el('div',{},el('span',{},'01'),el('strong',{},'The thought arrives'),p('“The whole walk was pointless.”')),el('div',{},el('span',{},'02'),el('strong',{},'Notice the thought'),p('“I’m having the thought that the whole walk was pointless.”'))),p('The trail is still blocked. Notice what, if anything, changes before choosing a response.'))),el('div',{class:'defusion-intro-details'},el('section',{},el('p',{class:'eyebrow'},'WHAT TO EXPECT'),h('One thought at a time.'),el('ol',{class:'defusion-expect-list'},...[['Learn the idea','Read the short lesson or watch an optional demonstration.'],['Try the phrase','Use a fictional example or a manageable thought of your own.'],['Pause and notice','Notice what changed or stayed the same, then consider a response.']].map(([title,text],i)=>el('li',{},el('span',{},String(i+1).padStart(2,'0')),el('div',{},el('h3',{},title),p(text)))))),el('section',{class:'defusion-intro-safety'},el('p',{class:'eyebrow'},'BEFORE YOU BEGIN'),h('Leave room for your experience.'),p('You can use a made-up example or an ordinary situation that feels manageable. No change in feeling or completed action is required.'),p('Thinking or talking uses no microphone. Every written note is optional.'))),el('section',{class:'values-intro-note'},p('Your words and choices stay in this open exercise. Leaving or refreshing clears them. Before finishing, you can choose which written notes to download.'),row(link('Teaching card (PDF)','noticing-thoughts-teaching-card.pdf'),link('Optional worksheet (PDF)','noticing-thoughts-teaching-and-practice.pdf'))));return;
  }
  if(step==='finished'){root.append(el('h1',{tabindex:'-1'},'You can leave it here'),el('section',{class:'exercise-end'},h('Notice the thought. Consider your response.'),p('The thought may still be there. You can attend to what the situation needs without waiting for certainty or a different feeling.'),p('Your on-page words and choices have been cleared. Files you chose to save remain where you saved them.'),row(button('Return to the introduction',()=>go('intro'),true),link('Keep the teaching card (PDF)','noticing-thoughts-teaching-card.pdf'))));return;}
  root.append(el('h1',{tabindex:'-1'},'Step back from a thought'),el('ol',{class:'values-progress','aria-label':'Exercise sections'},['Short lesson','Worked example','Optional practice','Take away'].map((s,i)=>el('li',i===(step==='lesson'?0:step.startsWith('example')?1:['mode','switch','thought','notice','pause','respond','review','stream'].includes(step)?2:3)?{'aria-current':'step'}:{},el('span',{},String(i+1).padStart(2,'0')),s))));
  const b=el('section',{class:'activity-board values-board'});root.append(b);
  if(entry==='lesson'&&step==='lesson')b.append(row(el('a',{class:'button',href:'#learn/leaves-on-a-stream'},'Return to Leaves practice card'),el('a',{class:'button',href:'#play/leaves-on-a-stream'},'Practice Leaves on a Stream')));
  if(step==='stream'){
   b.append(h('Leaves on a Stream'));const mount=el('div',{class:'stream-mount'});b.append(mount,row(button('Return to take away',()=>go('keep'))));
   Promise.resolve({mountStream:mount=>{mount.append(p('Animated Leaves practice is held pending selection and review of one variant. The written thought-noticing lesson remains available.'));return{dispose(){}}}}).then(({mountStream})=>{if(step!=='stream'||lifecycle.signal.aborted||!mount.isConnected)return;streamController=mountStream(mount,{assetBase:'defusion-media/leaves-stream/',onExit:()=>go('keep')});}).catch(()=>{if(step==='stream')mount.append(p('The visual practice is unavailable. Read or keep a thought in mind and notice it as thinking; no picture is needed. A thought may stay while you choose a response or pause. No removal or better feeling is required.'));});
  }else if(step==='lesson'){
   b.append(h('Hear the thought, then widen your view'),p('A thought can sound like a fact, prediction or instruction. Try noticing that you are thinking it before deciding what to do.'),p('Read the idea below or watch the optional video; you do not need to do both.'),film(),el('h3',{},'Read the idea'),el('div',{class:'values-comparison'},el('section',{},el('h3',{},'As it arrives'),p('“The whole walk was pointless.”')),el('section',{},el('h3',{},'Naming it'),p('“I’m having the thought that the whole walk was pointless.”'))),p('Keep the thought’s meaning. Add words that help you recognize it as something your mind is saying. You can think the phrase silently or say it aloud once; there is no need to repeat until you feel better.'),p('After trying the phrase, pause: what, if anything, changed about how the thought landed? What stayed the same? More room to choose, awkwardness, uncertainty or no difference are all possible.'),p('Then look at the situation and your options. A concern can be accurate and still be a thought you notice. You may need information, a practical solution, support or rest.'),p('This practice does not ask you to test the evidence or replace the thought with a positive one. It asks how you might respond while the thought is present.'),row(button('Work through Sam’s example',()=>{exampleId='walk';phrase=null;response=null;go('example-notice');},true),button('Try my own situation',own),button('Finish after the lesson',()=>go('keep'))));
  }else if(step==='example-choose'){
   b.append(h('Choose an everyday example'),p('Each example keeps the original thought and the practical situation in view.'),el('div',{class:'values-options'},Object.entries(content.examples).map(([id,e])=>pick(e.title,exampleId===id,'defusion-example-'+id,()=>{exampleId=id;phrase=null;response=null;}))),row(button('Try the noticing words',()=>go('example-notice'),true),button('Read the example without choosing',()=>{exampleId='walk';reading=true;go('example-response');})));
  }else if(step==='example-notice'){
   const e=content.examples[exampleId];b.append(h(e.title),p(e.context),phraseCard(e.thought),p('First bring these words to mind, silently or aloud, and notice how they land. Then try the noticing version below with the same thought.'),p('Which wording names the thought without changing what it says? Explore either version, or continue without answering.'),el('div',{class:'values-options'},pick(naming(e.thought),phrase===0,'defusion-phrase-0',()=>phrase=0),pick(exampleId==='walk'?'The walk was worthwhile after all.':exampleId==='task'?'I will get it right.':'They will be happy to hear from me.',phrase===1,'defusion-phrase-1',()=>phrase=1)));
   if(phrase!==null)b.append(feedback(phrase===0?'The thought is being named':'That changes the thought’s content',phrase===0?'The original words are still there. The added phrase names the act of thinking; it does not decide whether the thought is true.':'This gives a different judgement or prediction. You do not have to replace the original thought to try noticing it.'));
   b.append(row(button(phrase===null?'Continue without answering':'Try it and pause',()=>go('example-pause'),true)));
  }else if(step==='example-pause'){
   const e=content.examples[exampleId];b.append(h('Try it, pause, and notice'),phraseCard(e.thought,true),p('Think or say the noticing phrase once. Pause for a moment at your own pace. What, if anything, changed about how that thought landed? What stayed the same?'),p('You might notice more room to choose, awkwardness, uncertainty, or no difference. There is no answer you need to reach.'),row(button('Consider a response',()=>go('example-response'),true),button('Continue without answering',()=>go('example-response')),button('Back to the noticing words',()=>go('example-notice'))));
  }else if(step==='example-response'){
   const e=content.examples[exampleId];b.append(h('What could fit the situation?'),el('details',{},el('summary',{},'Read the situation again'),p(e.context)),phraseCard(e.thought,true),p(exampleId==='walk'?'The tree still blocks the route. Sam can still be disappointed. Choose an option to explore; neither removes the obstacle.':'The thought can remain. Explore a possible response without guaranteeing how it will turn out.'),el('div',{class:'values-options'},e.options.map(([label],i)=>pick(label,response===i,'defusion-response-'+i,()=>response=i))));
   if(response!==null)b.append(feedback(e.options[response][0],e.options[response][1]));
   b.append(row(button('Bring the example together',()=>go('example-summary'),true),button('Back to the noticing words',()=>go('example-notice'))));
  }else if(step==='example-summary'){
   const e=content.examples[exampleId];b.append(h('The thought and the response can coexist'),el('dl',{class:'values-recap'},el('dt',{},'The situation'),el('dd',{},e.context),el('dt',{},'The thought being noticed'),el('dd',{},naming(e.thought)),el('dt',{},response===null?'A possible response to consider':'The response you explored'),el('dd',{},e.options[response??0][0]),el('dt',{},'What this illustrates'),el('dd',{},e.options[response??0][1])),p('This is a possibility, not something the example proves will help. You can consider a response without acting on it. The thought and feeling do not have to change first.'),row(button(started?'Return to my practice':'Try my own situation',own,true),button('Choose another example',example),button('Finish with the example',()=>go('keep'))));
  }else if(step==='mode'){
   b.append(h('How would you like to practise?'),p('Choose an ordinary or made-up situation that feels manageable. You can leave every part open.'),row(button('Write optional notes',()=>{mode='write';started=true;go('thought');},true),button('Think or talk without typing',()=>{mode='spoken';started=true;go('thought');}),button('Use a fictional example instead',example)));
  }else if(step==='thought'){
   b.append(h('Notice what your mind is saying'),p('Bring one everyday situation to mind. What words show up? You do not need to choose your most difficult thought.'),p('Pause briefly and notice how the thought lands before adding any new words. No rating is needed.'),p('You might use “I’ll get it wrong” before starting a piece of writing. Describe your own thought in words that fit you.'));
   if(mode==='write')b.append(field(0,'Situation and thought (optional)','A few words of context and the thought as it arrives.'));
   else b.append(p('Think or say the situation and thought. Nothing is recorded here.'));
   b.append(row(button('Try noticing words',()=>go('notice'),true)));
  }else if(step==='notice'){
   b.append(h('Try naming it as a thought'),p('Try “I’m having the thought that…” followed by the thought you noticed. Another option is “I notice my mind is saying…”. Use wording that feels understandable rather than forcing a particular phrase.'),p('Keep the meaning of the original thought. You are naming it, rather than having to agree, disagree, or turn it into something positive.'));
   if(mode==='write')b.append(el('div',{class:'values-context'},p('Your situation and thought: '+(words[0].trim()||'Left open. You can use a fictional thought or think it privately.'))),field(1,'Noticing words I tried (optional)','For example: I’m having the thought that I’ll get it wrong.'));
   else b.append(el('div',{class:'defusion-phrase'},el('p',{class:'meta'},'Finish with the thought you’re keeping in mind'),p('I’m having the thought that…')));
   b.append(p('Think or say the phrase once if you wish. Then pause and notice, without needing to change the thought or feeling.'),row(button('Pause and notice',()=>go('pause'),true),button('Back to my thought',()=>go('thought'))));
  }else if(step==='pause'){
   b.append(h('What, if anything, feels different?'),p('Take a moment at your own pace. Compare how the thought landed before and after trying the phrase. What changed about your relationship with it? What stayed the same?'),p('You might notice more room to choose, no difference, awkwardness or discomfort. You do not have to feel calmer or believe the thought less. There is no need to keep repeating until something changes.'));
   if(mode==='write')b.append(field(4,'What I noticed after trying the phrase (optional)','A difference, something unchanged, uncertainty, or no difference.'));
   else b.append(p('Notice privately or talk about what happened. You can leave it uncertain.'));
   b.append(row(button('Consider my response',()=>go('respond'),true),button('Back to noticing words',()=>go('notice'))));
  }else if(step==='respond'){
   b.append(h('What does this situation need?'),p('With the thought still present, consider what matters and what fits the circumstances. A response might be a practical step, more information, support, rest, or leaving the decision open.'),p('Noticing a thought does not make a real obstacle disappear. Check safety, your needs, other people’s boundaries and the information you have.'));
   if(mode==='write')b.append(field(2,'A response I considered (optional)','Something I could do, say, find out, or leave for now.'));
   else b.append(p('Think or talk about one possible response. You do not have to carry it out.'));
   b.append(row(button('Review my practice',()=>go('review'),true),button('Back to noticing words',()=>go('notice'))));
  }else if(step==='review'){
   b.append(h('What, if anything, did you notice?'),recap([0,1,4,2]),p('A change in feeling is not required. These options are invitations to reflect, not a score.'),el('div',{class:'values-options'},Object.keys(content.observations).map((s,i)=>pick(s,observation===s,'defusion-observation-'+i,()=>observation=s))));
   if(observation)b.append(feedback(observation,content.observations[observation]));
   if(mode==='write')b.append(field(3,'What I noticed or want to keep (optional)','A reminder, uncertainty or question for later.'));
   else b.append(p('You can keep a private reminder or a question for a later conversation.'));
   b.append(row(button('Choose a takeaway or finish',()=>go('keep'),true),button('Revisit my possible response',()=>go('respond'))));
  }else if(step==='variations'){
   b.append(h('Try another way of hearing or seeing the thought'),p('These optional experiments change how the same words are presented. Choose one that fits you. You do not have to find it funny or make it feel different.'),p('A playful voice or tune is a choice you make; your concern still deserves respect. A quiet paper option is available too.'),el('div',{class:'values-options'},['Sing the thought','Change the voice','Put it on paper','Leaves on a Stream'].map((name,i)=>pick(name,variation===i,'defusion-variation-'+i,()=>variation=i))));
   if(variation!==null)b.append(row(button('Try this variation',()=>go(variation===3?'stream':'variation-practice'),true)));
   b.append(row(button('Skip variations and return to take away',()=>go('keep'))));
  }else if(step==='variation-practice'){
   const names=['Sing the thought','Change the voice','Put it on paper'];
   b.append(h(names[variation]),p('Use a manageable or fictional thought. Keep its words rather than changing the message.'),el('div',{class:'values-options'},pick('Use the fictional thought: I’ll get it wrong.',variationThought==='fictional','defusion-variation-fictional',()=>variationThought='fictional'),pick('Use a thought I’m keeping in mind',variationThought==='private','defusion-variation-private',()=>variationThought='private')));
   b.append(el('div',{class:'values-context'},p(variationThought==='fictional'?'Your practice words: “I’ll get it wrong.”':'Keep the exact words of your chosen thought in mind. You do not need to type or share them.')));
   const prompts=[['Try a familiar tune','Sing the thought once to a familiar tune, such as Happy Birthday, aloud or in your mind. Notice the words as sounds and rhythm. You do not need to perform or make yourself laugh.'],['Try another voice','Try the same words once in a robot voice, cartoon voice or exaggerated announcer voice, aloud or in your mind. Choose a voice that feels okay to you.'],['Look at the written words','Write the thought on a piece of paper. Look at the letters, spaces and marks that make up the sentence. Notice that you are looking at words expressing a thought. You do not need to cross it out or throw it away.']][variation];
   b.append(el('h3',{},prompts[0]),p(prompts[1]),el('h3',{},'Pause and notice'),p('What, if anything, changed about how that thought landed? What stayed the same? No difference, uncertainty or discomfort are possible. You can stop; a real concern or practical need still matters.'));
   if(started&&mode==='write')b.append(field(3,'A variation or observation I want to keep (optional)','Keep or add to your takeaway: the approach you tried and what you noticed.'));
   else b.append(p('Keep a private reminder or question only if you want one.'));
   b.append(row(button('Return to take away',()=>go('keep'),true),button('Choose another variation',()=>go('variations'))));
  }else if(step==='switch'){
   b.append(h(mode==='write'?'Switch to thinking or talking?':'Switch to written practice?'),p('Changing mode clears your current practice notes and choices. Return to keep working with them.'));
   if(mode==='write'&&words.some(w=>w.trim()))b.append(button('Choose notes to keep first',()=>go('export')));
   b.append(row(button('Clear this practice and switch mode',()=>{mode=mode==='write'?'spoken':'write';clear();started=true;go('thought');},true),button('Keep my current practice',()=>go(ownStep))));
  }else if(step==='export'){
   const printStatus=el('p',{role:'status'});const available=noteOrder.filter(i=>words[i].trim());selected=new Set([...selected].filter(i=>available.includes(i)));b.append(h('Choose the notes you want to keep'),p('Only checked sections go in the download or printed copy. Preview your selection below. Nothing is sent to your therapist.'),el('div',{class:'export-picks'},available.map(i=>el('label',{},el('input',{type:'checkbox',...(selected.has(i)?{checked:''}:{}),onchange:e=>{if(e.target.checked)selected.add(i);else selected.delete(i);draw();main.querySelectorAll('.export-picks input')[available.indexOf(i)]?.focus();}}),labels[i]))));
   if(selected.size){b.append(h('Preview of selected notes'),recap(noteOrder.filter(i=>selected.has(i))),row(button('Download selected notes',()=>download(noteOrder.filter(i=>selected.has(i))),true),button('Print or save selected notes as PDF',()=>printSelectedText(selectedText(noteOrder.filter(i=>selected.has(i))),printStatus))));}else b.append(p(available.length?'No sections selected yet.':'There are no written notes to select. You can keep the blank worksheet instead.'));
   b.append(printStatus,p('Close the separate selected-notes print window when finished. Clearing here does not close it. Saved files and printouts remain where you keep them after you clear this page.'),row(button('Return to take away',()=>go('keep'))));
  }else if(step==='keep'){
   b.append(h('Take what is useful, or leave it here'),p('A simple reminder: “Notice the thought. Look at the situation. Consider a response.” You can keep a question instead, including whether this practice fits you.'),...(started?[recap()]:[]),row(...(mode==='write'&&words.some(w=>w.trim())?[button('Choose notes to download or print',()=>go('export'),true)]:[]),link('Keep the teaching card (PDF)','noticing-thoughts-teaching-card.pdf'),link('Keep the blank worksheet (PDF)','noticing-thoughts-teaching-and-practice.pdf')),p('Before clearing, save any notes you want. Finishing removes your on-page words and choices.'),el('section',{class:'defusion-extension'},el('h3',{},'Optional: try another approach'),p('Sing the thought, change its voice, or look at it on paper. Try one, then pause and notice what changed or stayed the same.'),button('Explore optional variations',()=>go('variations'))),row(button('Finish and clear this exercise',()=>{clear();go('finished');},true),...(started?[button('Return to my practice',own)]:[])));
  }
  if(!['keep','export','switch','variations','variation-practice','stream'].includes(step)){const nav=secondary();for(const control of nav.querySelectorAll('button')){if([...b.querySelectorAll('button')].some(x=>x.textContent===control.textContent)||(['thought','notice','pause','respond','review'].includes(step)&&control.textContent==='Return to my practice'))control.remove();}root.append(nav);}if(started&&['thought','notice','pause','respond','review'].includes(step))root.append(row(button('Change how I practise',()=>go('switch'))));
 }
 draw();
}

return {renderDefusion};})();